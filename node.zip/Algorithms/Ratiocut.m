function V=Ratiocut(W,nClass,nata2)
%% nata1*trace(V'LV)+nata2*[tr(V'*V)-log(det(V'*V))]
nata1=1;
[~,n]=size(W);
W=W.*(ones(n,n)-eye(n));
D=diag(sum(W));
L=D-W;
%%
% L=(eye(n)-W)*(eye(n)-W)';�ɲ���
%%
D=(abs(L)+L)/2;
W=(abs(L)-L)/2;
%%
% L=(eye(Xn)-W)*(eye(Xn)-W)';
%%
%%
% [~,Xn]=size(W);
% D1=diag((sum(W)).^(-0.5));%ע��ֻ�ڶԽ����Ͽ�����
% L=eye(Xn)-D1*W*D1;
% D=eye(Xn);
%%
k=nClass;
% tStart=tic;
% optionDefault.distance='ls';%ls,kl
optionDefault.iter=1000;%1000
optionDefault.dis=true;
optionDefault.residual=1e-4;
optionDefault.tof=1e-4;
option=optionDefault;

% iter: number of iterations
[~,c]=size(W); % c is # of samples, r is # of features
% performS=[];perform=[];
% Vsave=[];
% bata=0.5;
% for loop=1:1
rand('twister',5489);
%     RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
V=rand(c,k);V=max(V,eps);
% XfitPrevious=Inf;
%%
for i=1:option.iter
    %         switch option.distance
    %             case 'ls'
    %%
    if nata2~=0
        p0=V*inv(V'*V);%fast
    else
        p0=zeros(c,k);
    end
    
    p12=nata2*(abs(p0)+p0)/2;
    p22=nata2*(abs(p0)-p0)/2;
    %                 else
    %                     p12=zeros(c,k);
    %                     p22=p12;
    %                 end
    p11=nata1*W*V;
%     p23=nata2*V;%normalzied
    p23=nata2*V;%unnormalized
    
    p21=nata1*D*V;
    
    
    
    %                 V=V.*(1-bata+bata*(p11+p12)./(p21+p22+p23));%�Ǹ�
    %% 1
    %     temp=eps*(p21+p22+p23<eps);
    %     V=V.*((p11+p12)./(p21+p22+p23+temp));
    %% 2
    V=V.*((p11+p12)./(p21+p22+p23));%�Ǹ�
    V=max(V,eps);
    %             case 'kl'
    %             otherwise
    %                 error('Please select the correct distance: option.distance=''ls''; or option.distance=''kl'';');
%         perform(i)=trace(V'*L*V)+(nata2/nata1)*(trace(V'*V)-log(det(V'*V)));
end
%         performS0(i)=nata1*trace(V'*L*V);
%         performS1(i)=nata2*trace(V'*V)-nata2*log(det(V'*V));
%         performall(i)=nata1*trace(V'*(D-W)*V)+performS1(i);
% end
% tElapsed=toc(tStart);
% subplot(3,2,1),plot(performG,'DisplayName','performG','YDataSource','performG');title('performG')
% subplot(3,2,2),plot(performS,'DisplayName','performG','YDataSource','performG');title('performS')
% subplot(3,2,4),plot(performall,'DisplayName','performG','YDataSource','performG');title('performD')
% performS(loop)=trace(V'*L*V)+(nata2/nata1)*(trace(V'*V)-log(det(V'*V)));
% Vsave(:,:,loop)=V;
% end
% min(performS);
% [~,fn1]=min(performS);%����ֵ��Сֵ
% V=Vsave(:,:,fn1);
%%
% [MIHat,AC]=computeMIAC(gnd,V,nClass);
% % AC11(nata22)= AC
% AC11(k)= AC
% end