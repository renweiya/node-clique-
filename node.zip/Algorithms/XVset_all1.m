XVset_all=[];
clip_dir = 'video_clips';load humanGT.mat;sub_dirs=GT_videoIndex;
for idx=1:413
    idx
    folder=sub_dirs{idx};
    %%
    curVideo = fullfile('video_clips', folder);
    
    % curVideo = 'realcrowd\';
    curTrkName = 'klt_3000_10_trk.txt';
    %     curTrkName = 'klt_3000_10_trk_filt.txt';
    %%
    
    %%
    curClipFrameSet = dir([curVideo '\*.jpg']);
    curTrks = readTraks([curVideo '\' curTrkName]);
    [XVset] = trk2XV(curTrks, 1, 2); %��Ҫһ�д���-�켣���� % transform trajectories into point set
    XVset_all{idx}=XVset;
end
% save XVset_all.mat