function [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all(crowd_total,Human_table,Human_table_mod,select)
Human_table=Human_table(1:length(crowd_total));
Human_table_mod=Human_table_mod(1:length(crowd_total));

if select==1
    high=(Human_table>15)+(Human_table==15);
    media=(Human_table<15).*(Human_table>5);
    low=(Human_table<5)+(Human_table==5);
    high=logical(high);media=logical(media);low=logical(low);
%     sum(high)
%     sum(media)
%     sum(low)
%     sum(high)+sum(media)+sum(low)
end
if select==2
    high=(Human_table_mod==2);
    media=(Human_table_mod==1);
    low=(Human_table_mod==0);
end


acu_high_low=[];
i=1;
for threshold=0:0.01:1
    geshu=sum(crowd_total(high)<threshold)+sum(crowd_total(low)>threshold);
    acu_high_low(i)=1- geshu/(sum(high)+sum(low));
    
    
%     acu_high_low(i)=1- (sum(crowd_total(high)<threshold)/sum(high)+sum(crowd_total(low)>threshold)/sum(low))/2;
    
    
    i=i+1;
end

acu_media_low=[];
i=1;
for threshold=0:0.01:1
    geshu=sum(crowd_total(media)<threshold)+sum(crowd_total(low)>threshold);
    acu_media_low(i)=1- geshu/(sum(media)+sum(low));
    i=i+1;
end

acu_high_media=[];
i=1;
for threshold=0:0.01:1
    geshu=sum(crowd_total(high)<threshold)+sum(crowd_total(media)>threshold);
    acu_high_media(i)=1- geshu/(sum(high)+sum(media));
    i=i+1;
end

acu_high_media=max(acu_high_media);
acu_media_low=max(acu_media_low);
acu_high_low=max(acu_high_low);