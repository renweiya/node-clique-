function [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_2(crowd_total,Human_table,Human_table_mod,select)
Human_table=Human_table(1:length(crowd_total));
Human_table_mod=Human_table_mod(1:length(crowd_total));

if select==1
    high=(Human_table>15)+(Human_table==15);
    media=(Human_table<15).*(Human_table>5);
    low=(Human_table<5)+(Human_table==5);
    high=logical(high);media=logical(media);low=logical(low);
%     sum(high)
%     sum(media)
%     sum(low)
%     sum(high)+sum(media)+sum(low)
end
if select==2
    high=(Human_table_mod==2);
    media=(Human_table_mod==1);
    low=(Human_table_mod==0);
end

%
alfa=0.1;linear=0;
%
x=[crowd_total(high),crowd_total(low)];
x=x';
training_label_vector=[ones(1,sum(high)),-1*ones(1,sum(low))];
training_label_vector=training_label_vector';
model = svm_learning(x, training_label_vector,linear,alfa);
[~, acu_high_low, ~] = svm_classifying(model, x, training_label_vector, linear);
%%
x=[crowd_total(high),crowd_total(media)];
x=x';
training_label_vector=[ones(1,sum(high)),-1*ones(1,sum(media))];
training_label_vector=training_label_vector';
model = svm_learning(x, training_label_vector,linear,alfa);
[~, acu_high_media, ~] = svm_classifying(model, x, training_label_vector, linear);
%%
x=[crowd_total(media),crowd_total(low)];
x=x';
training_label_vector=[ones(1,sum(media)),-1*ones(1,sum(low))];
training_label_vector=training_label_vector';
model = svm_learning(x, training_label_vector,linear,alfa);
[~, acu_media_low, ~] = svm_classifying(model, x, training_label_vector, linear);
