function [weightedAdjacencyMatrix,neighborMatrix] = computeAdj(curX, curV, K)
distanceMatrix = slmetric_pw(curX',curX','eucdist');
correlationMatrix = slmetric_pw(curV',curV','nrmcorr');
[n,~]=size(curV);
K=min(K,n-1);
%% K-nearest neighbor adjacency matrix
neighborMatrix = zeros(size(distanceMatrix,1));
for i=1:size(distanceMatrix,1)
    [~,neighborIndex] = sort(distanceMatrix(i,:),'ascend');
    neighborMatrix(i,neighborIndex(2:K+1)) = 1;
end
weightedAdjacencyMatrix = (correlationMatrix.*neighborMatrix);%weigted adjacency matrix
weightedAdjacencyMatrix=max(0,weightedAdjacencyMatrix);%���ӣ������ǷǸ���
weightedAdjacencyMatrix=min(weightedAdjacencyMatrix,1);%���ȴ���, Dec 03, 2016.
