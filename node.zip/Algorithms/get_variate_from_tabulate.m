function variate_forsparse=get_variate_from_tabulate(clusterIndex)
tempforcn= ceil(tabulate(clusterIndex));
en=tempforcn(:,2);
if sum(clusterIndex==0)>0
    en(1)=[];
end
en=en./max(max(en));

variate_forsparse=log(2)*exp( -abs(median(en)-max(en) )- abs(mean(en)-max(en) ))/log(length(en));

% variate_forsparse=log(2)*exp( -abs(mean(en)-max(en)))/log(length(en));

% variate_forsparse=sum(en)/length(en);
% variate_forsparse=1+(sum(en)*length(en))/100;
% variate_forsparse=min(2,variate_forsparse);