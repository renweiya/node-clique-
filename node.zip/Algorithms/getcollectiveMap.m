    function intialMap=getcollectiveMap(curX,collectivenessSet,Lm,Ln)
    % �õ�һ֡�� ÿ�����collective
    intialMap=zeros(Lm,Ln);
    for q=1:size(curX,1)
        local=curX(q,:);
        intialMap(local(2),local(1))=collectivenessSet(q);
    end