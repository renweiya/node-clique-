function [WG2,WG3,rightpoint2,rightpoint3]=getgraph3(Zmatrix,weightedAdjacencyMatrix,curX, curV,clusterIndex,para)
%% threshold
% WG2 = Zmatrix > para.threshold;%0-1ͼ�����Գ�
[n,~]=size(Zmatrix);
alone_point=find(clusterIndex==0);
% WG2(alone_point,:)=0;
% WG2(:,alone_point)=0;
curX(alone_point,:)=[];
curV(alone_point,:)=[];
% noisepoint2=alone_point;
rightpoint2=setdiff((1:n),alone_point);
para.K=20;
[WG2,~] = computeAdj_new(curX, curV, para.K);

% �Գƻ�
% WG2=max(WG2,WG2');
% noisepoint2=find(sum(WG2,2)==0);%������
% rightpoint2=find(sum(WG2,2)~=0);
% ȥ��������
% WG2(noisepoint2,:)=[];WG2(:,noisepoint2)=[];
% WG2=real(WG2);
%%
WG3 = Zmatrix > para.threshold;%0-1ͼ�����Գ�
% WG3=weightedAdjacencyMatrix;%WG2(weightedAdjacencyMatrix<0.7)=0;%weight ͼ
alone_point=find(clusterIndex==0);
WG3(alone_point,:)=0;
WG3(:,alone_point)=0;
%
% WG2=WG2./max(max(abs(WG2)));
WG3=max(WG3,WG3');
noisepoint3=find(sum(WG3,2)==0);%������
rightpoint3=find(sum(WG3,2)~=0);
% ȥ��������
WG3(noisepoint3,:)=[];WG3(:,noisepoint3)=[];
WG3=real(WG3);