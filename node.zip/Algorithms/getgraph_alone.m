function [WG,rightpoint,nclass]=getgraph_alone(curX,curV,clusterIndex,K)
%% threshold
[n,~]=size(curX);
alone_point=find(clusterIndex==0);
curX(alone_point,:)=[];
curV(alone_point,:)=[];
% noisepoint=alone_point;
rightpoint=setdiff((1:n),alone_point);
[WG,~] = computeAdj_new(curX, curV, K);
nclass=max(clusterIndex);
