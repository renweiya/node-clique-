function [WG2,rightpoint2,nclass]=getgraph_byZ(Zmatrix,clusterIndex,threshold)
%% threshold
WG2 = Zmatrix;% > threshold;%0-1ͼ�����Գ�
alone_point=find(clusterIndex==0);
WG2(alone_point,:)=0;
WG2(:,alone_point)=0;
%%
WG2=max(WG2,WG2');
%%
noisepoint2=find(sum(WG2,2)==0);%������
rightpoint2=find(sum(WG2,2)~=0);
% ȥ��������
WG2(noisepoint2,:)=[];WG2(:,noisepoint2)=[];
WG2=real(WG2);nclass=max(clusterIndex);