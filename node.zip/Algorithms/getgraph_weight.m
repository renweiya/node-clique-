function [WG,rightpoint,nclass]=getgraph_weight(weightedAdjacencyMatrix,clusterIndex)
%% 1
WG=weightedAdjacencyMatrix;WG=(WG+WG')/2;
alone_point=find(clusterIndex==0);
WG(alone_point,:)=0;
WG(:,alone_point)=0;
%
noisepoint=find(sum(WG,2)==0);%������
rightpoint=find(sum(WG,2)~=0);
% ȥ��������
WG(noisepoint,:)=[];WG(:,noisepoint)=[];
WG=real(WG);nclass=max(clusterIndex);
