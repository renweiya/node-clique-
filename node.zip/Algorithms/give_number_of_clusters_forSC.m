function nClass=give_number_of_clusters_forSC(WG)
W=WG;[n0,~]=size(W);
D=diag(sum(W));
D1=diag((sum(W)).^(-0.5));
L=D1*(D-W)*D1;
C=full(L);[vectors,values]=eig(C);values=sum(values);
margin=[];
for tempj=1:length(values)-1
    margin(tempj)=abs(values(tempj)-values(tempj+1));
end
[m,nClass1]=max(margin);
nClass1=n0-nClass1;
nClass=nClass1;
