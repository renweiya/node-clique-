function fea=guiyihua(fea,method)
[n,m]=size(fea);
switch method
    case 1 %ƽ���͹�һ
        fea00=sqrt(sum(fea.^2,2));
        for datai=1:n
            fea(datai,:)= fea(datai,:)/fea00(datai);
        end
    case 2%���ֵ��һ
        fea=fea/max(max(abs(fea)));
    case 3 %�����ֵ��һ
        for datai=1: n
            fea(datai,:)= fea(datai,:)/max( fea(datai,:));
        end
    case 4%ά�ȹ�һ��
        X=fea';
        X00=sqrt(sum(X.^2,2))+eps;
        for datai=1:m
            X(datai,:)= X(datai,:)/X00(datai);
        end
        fea=X';
    case 5 %�к͹�һ
        for datai=1: n
            fea(datai,:)= fea(datai,:)/sum( fea(datai,:));
        end
end

