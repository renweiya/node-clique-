function V=normalizedlaplacian(W,k)
D=diag(sum(W));
D1=diag((sum(W)).^(-0.5));
L=D1*(D-W)*D1;
C=full(L);[vectors,values]=eig(C);values=sum(values);[~,xuhao]=sort(values);
V=vectors(:,xuhao(2:k+1));
V=D1*V;