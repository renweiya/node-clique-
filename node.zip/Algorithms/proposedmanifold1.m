function [U,V]=proposedmanifold1(X,W,nClass,nata1,nata2,nor,select) % O+tr(V'*V)-log(det(V'*V)),ʹ��V'*V�ӽ�I
%%
[Xm,Xn]=size(X);
% nata1=50;%GNMF,100
% nata2=100; % yale,nata2=500;ORL,nata2=200~250, %tr(U'*U)-logdet(U'*U),tr(V'*V)-logdet(V'*V)
D=diag(sum(W));
% L=D-W;
[n,n]=size(W);
% if nor==1
    %% normalized
    D1=diag(((sum(W))).^(-0.5));
    L=eye(n)-D1*W*D1;
    D=(abs(L)+L)/2;
    W=(abs(L)-L)/2;
% end
%%
k=nClass;
tStart=tic;
optionDefault.distance='ls';%ls,kl
optionDefault.iter=1000;%1000
optionDefault.dis=true;
optionDefault.residual=1e-4;
optionDefault.tof=1e-4;
option=optionDefault;

% iter: number of iterations
[r,c]=size(X); % c is # of samples, r is # of features
performS=[];
Vsave=[];
V=rand(c,k);
V=max(V,eps);
% for loop=1:1
%     RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
%     V=rand(c,k);
    U=rand(Xm,k);
    U=max(U,eps);
    XfitPrevious=Inf;
%     %%
% U=X/V';U=max(U,eps);
for i=1:option.iter
    switch option.distance
        case 'ls'
            U=U.*((X*V)./(U*(V'*V)));%�Ǹ�
            U=max(U,eps);
            %%
            if nata2~=0
                p0=V*inv(V'*V);%fast
            else
                p0=zeros(c,k);
            end
            p11=nata1*W*V;
            p12=nata2*(abs(p0)+p0)/2;
            p22=nata2*(abs(p0)-p0)/2;
            
            p23=nata2*V;
            if select==1
                p23=nata2*(1/ceil(Xn/k))*V;
            end
            p21=nata1*D*V;
            
            V=V.*((X'*U+p11+p12)./(V*(U'*U)+p21+p22+p23));%�Ǹ�
            V=max(V,eps);
        case 'kl'
        otherwise
            error('Please select the correct distance: option.distance=''ls''; or option.distance=''kl'';');
    end
    if mod(i,500)==0 || i==option.iter
        if option.dis
            %disp(['Iterating >>>>>> ', num2str(i),'th']);
        end
        XfitThis=U*V';
        fitRes=matrixNorm(XfitPrevious-XfitThis);
        XfitPrevious=XfitThis;
        curRes=norm(X-XfitThis,'fro');
        if option.tof>=fitRes || option.residual>=curRes || i==option.iter
            %s=sprintf('Mutiple update rules based NMF successes! \n # of iterations is %0.0d. \n The final residual is %0.4d.',i,curRes);
            %disp(s);
            numIter=i;
            finalResidual=curRes;
            break;
        end
    end
    %                 performG(i)=(sum(sum( (X-U*V').^2 )));%�����
    %                 performS(i)=nata2*trace(V'*V)-nata2*log(det(V'*V));
    %                 performall(i)=performG(i)+nata1*trace(V'*(D-W)*V)+performS(i);
end
if nor==0
    V=D1*V;
end