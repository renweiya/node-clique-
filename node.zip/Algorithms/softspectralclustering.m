%% argmin nata1*trace(VLV')+nata2*[tr(V'*V)-log(det(V'*V))]
function V=softspectralclustering(W,nClass,nata2,nor)
if ~isempty(find(sum(W,2)==0, 1))
    disp('Graph error');
end
%% nata1*trace(V'LV)+nata2*[tr(V'*V)-log(det(V'*V))]
nata1=1;
[~,n]=size(W);
W=W.*(ones(n,n)-eye(n));
%% normalized
D1=diag(((sum(W))).^(-0.5));
L=eye(n)-D1*W*D1;
%%
LLE=0;
if LLE==1
    L=(eye(n)-W)*(eye(n)-W)';%�ɲ���
end
%%
D=(abs(L)+L)/2;
W=(abs(L)-L)/2;
%%
%%
k=nClass;
optionDefault.iter=2000;%1000
optionDefault.dis=true;
optionDefault.residual=1e-4;
optionDefault.tof=1e-4;
option=optionDefault;
[~,c]=size(W); % c is # of samples, r is # of features
rand('twister',5489);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
% RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
V=rand(c,k);V=max(V,eps);
%%
for i=1:option.iter
    %%
    if nata2~=0
        p0=V*inv(V'*V);%fast
    else
        p0=zeros(c,k);
    end
    p12=nata2*(abs(p0)+p0)/2;
    p22=nata2*(abs(p0)-p0)/2;
    p11=nata1*W*V;
    p23=nata2*V;%
    p21=nata1*D*V;
    %% 1
    %     temp=eps*(p21+p22+p23<eps);
    %     V=V.*((p11+p12)./(p21+p22+p23+temp));
    %% 2
    V=V.*((p11+p12)./(p21+p22+p23));%�Ǹ�
    V=max(V,eps);
%     perform_all(i)=trace(V'*L*V)+nata2*(trace(V'*V)-log(det(V'*V)));
%     perform_xishu(i)=sparseness(V);
end
if nor==0
    V=D1*V;
end
