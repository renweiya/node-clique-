function [msparse,sparse]=sparseness(V)
% һ��һ��Ԫ��
[Vm,Vn]=size(V);
for i=1:Vm
    V(i,:)=V(i,:)./max(eps,sqrt(sum(V(i,:).^2)));
    sparse(i)=(sqrt(Vn)-sum(abs(V(i,:)))/sqrt(sum((V(i,:).^2))))/(sqrt(Vn)-1);
end
msparse=mean(sparse);