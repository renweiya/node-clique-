hmidia=zeros(1,413);hlow= hmidia;hhigh=hlow;
for i=1:413
    hh=GT_human(:,i);
    hmidia(i)=length(find(hh==1));
    hlow(i)=length(find(hh==0));
    hhigh(i)=length(find(hh==2));
end

s=(hmidia==5).*(hhigh==5)+(hmidia==4).*(hhigh==4);
sum(s)
s1=find(s==1)

s=(hmidia==5).*(hlow==5)+(hmidia==4).*(hlow==4);
sum(s)
s2=find(s==1)

Human_table_mod(s1)
Human_table_mod(s2)
%�ҳ�ͶƱ����ͬ�������������