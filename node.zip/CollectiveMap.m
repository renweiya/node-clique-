do_map=3;%1,2,3
% 1.ԭʼ�㼯���Ե��ۻ�
% 2.����Ƶ�ֿ飬ÿһ��ļ�����
% 3.ÿ�����صļ�����������Χһ����Χ���м����Եĵ�ļ����Ժ�
% implay(Map);
load Map2.mat
 Map1=Map2;
if do_map==1

    %     Map1(Map1<0)=0;
    count=1;figure;interval=24;
    for i = interval+1:length(curClipFrameSet)
        %%  hold off,
        if i>interval
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            
            for j=i-interval:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %%
            Collectivemap(Collectivemap<0)=0;
            %%
            a=imadd(Collectivemap,curFrame(:,:,1));
            imagesc(a)
            title([ 'Collective Map i=' num2str(i)])
            drawnow
        end
    end
    implay(Map);
end
%% ͼ��ֳ����ɸ�block Lm Ln

if do_map==2;
    xxx=45;%45
    yyy=60;%60
    Lm_m=Lm/xxx;
    Ln_n=Ln/yyy;
    %%
    %     Map1(Map1<0)=0;
    %%
    figure;
    interval=1;    interval2=24;    interval3=72;    interval4=144;
    for i =  interval+1:length(curClipFrameSet)
        %%  hold off,
        if i>interval
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ͼ��ֿ�
            Collectivemap_block=zeros(Lm,Ln);
            for block_x=1:xxx
                for block_y=1:yyy
                    x1=(block_x-1)*Lm_m+1;
                    x2=block_x*Lm_m;
                    y1=(block_y-1)*Ln_n+1;
                    y2=block_y*Ln_n;
                    Collectivemap_block(x1:x2,y1:y2)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_block=Collectivemap_block./max(max(Collectivemap_block));
            %%
            a=imadd(Collectivemap_block,curFrame(:,:,1));
            %             subplot(2,2,1),imagesc(a)
            subplot(2,2,1),imshow(curFrame)
            title([ 'Collective Map Frame=' num2str(i) '   Interval =' num2str(interval)])
            drawnow
            %             subplot(2,2,2),imagesc(Collectivemap_block)
            %             title([ 'Collective Map Frame=' num2str(i) '   Interval =' num2str(interval)])
            %             drawnow
        end
        if i>interval2
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval2:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ͼ��ֿ�
            Collectivemap_block=zeros(Lm,Ln);
            for block_x=1:xxx
                for block_y=1:yyy
                    x1=(block_x-1)*Lm_m+1;
                    x2=block_x*Lm_m;
                    y1=(block_y-1)*Ln_n+1;
                    y2=block_y*Ln_n;
                    Collectivemap_block(x1:x2,y1:y2)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_block=Collectivemap_block./max(max(Collectivemap_block));
            %%
            a=imadd(Collectivemap_block,curFrame(:,:,1));
            subplot(2,2,2),imagesc(a)
            %             subplot(2,2,2),imagesc(Collectivemap_block)
            title([ 'Collective Map Frame=' num2str(i) '  Interval=' num2str(interval2)])
            drawnow
        end
        if i>interval3
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval3:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ͼ��ֿ�
            Collectivemap_block=zeros(Lm,Ln);
            for block_x=1:xxx
                for block_y=1:yyy
                    x1=(block_x-1)*Lm_m+1;
                    x2=block_x*Lm_m;
                    y1=(block_y-1)*Ln_n+1;
                    y2=block_y*Ln_n;
                    Collectivemap_block(x1:x2,y1:y2)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_block=Collectivemap_block./max(max(Collectivemap_block));
            %%
            a=imadd(Collectivemap_block,curFrame(:,:,1));
            subplot(2,2,3),imagesc(a)
            title([ 'Collective Map Frame=' num2str(i) '  Interval=' num2str(interval3)])
            drawnow
        end
        if i>interval4
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval4:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ͼ��ֿ�
            Collectivemap_block=zeros(Lm,Ln);
            for block_x=1:xxx
                for block_y=1:yyy
                    x1=(block_x-1)*Lm_m+1;
                    x2=block_x*Lm_m;
                    y1=(block_y-1)*Ln_n+1;
                    y2=block_y*Ln_n;
                    Collectivemap_block(x1:x2,y1:y2)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_block=Collectivemap_block./max(max(Collectivemap_block));
            %%
            a=imadd(Collectivemap_block,curFrame(:,:,1));
            subplot(2,2,4),imagesc(a)
            title([ 'Collective Map Frame=' num2str(i) '  Interval=' num2str(interval4)])
            drawnow
        end
    end
    implay(Map);
end

%%
%% ����ÿ�����ص��Map
% ÿ������Χ��collective��ĺ� Lm Ln

if do_map==3;
    %     Lm;
    %     Ln;
    %%
    % Map1(Map1<0)=0;
    %%
    figure;
    interval=1;    interval2=24;    interval3=24;    interval4=144;
    for i =  interval+1:length(curClipFrameSet)
        %%  hold off,
        if i>interval
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ԭʼͼ��
            subplot(2,2,1),imshow(curFrame)
            title([ 'Collective Map Frame=' num2str(i) '   Interval =' num2str(interval)])
            drawnow
        end
        if i>interval2
            neighbor=10;
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval2:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ����ÿ�����ص�
            Collectivemap_every=zeros(Lm,Ln);
            for search_x=1:Lm
                for search_y=1:Ln
                    x1=max(1,search_x-neighbor);
                    x2=min(Lm,search_x+neighbor);
                    y1=max(1,search_y-neighbor);
                    y2=min(Ln,search_y+neighbor);
                    Collectivemap_every(search_x,search_y)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                    %                     Collectivemap_every(search_x,search_y)=mean(mean(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_every=Collectivemap_every./max(max(Collectivemap_every));
            %%
            a=imadd(Collectivemap_every,curFrame(:,:,1));
            subplot(2,2,2),imagesc(a)
            title([ 'Collective Map Frame=' num2str(i)  '   neighbor=' num2str(neighbor) '  Interval=' num2str(interval2)])
            drawnow
        end
        if i>interval3
            neighbor=20;
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval2:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ����ÿ�����ص�
            Collectivemap_every=zeros(Lm,Ln);
            for search_x=1:Lm
                for search_y=1:Ln
                    x1=max(1,search_x-neighbor);
                    x2=min(Lm,search_x+neighbor);
                    y1=max(1,search_y-neighbor);
                    y2=min(Ln,search_y+neighbor);
                    Collectivemap_every(search_x,search_y)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_every=Collectivemap_every./max(max(Collectivemap_every));
            %%
            a=imadd(Collectivemap_every,curFrame(:,:,1));
            subplot(2,2,3),imagesc(a)
            title([ 'Collective Map Frame=' num2str(i)  '   neighbor=' num2str(neighbor) '  Interval=' num2str(interval2)])
            drawnow
        end
        if i>interval4
            neighbor=20;
            curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
            curFrame = im2double(curFrame);
            Collectivemap=zeros(Lm,Ln);
            for j=i-interval2:i
                Collectivemap=Collectivemap+Map1(:,:,j);
            end
            %% ����ÿ�����ص�
            Collectivemap_every=zeros(Lm,Ln);
            for search_x=1:Lm
                for search_y=1:Ln
                    x1=max(1,search_x-neighbor);
                    x2=min(Lm,search_x+neighbor);
                    y1=max(1,search_y-neighbor);
                    y2=min(Ln,search_y+neighbor);
                    Collectivemap_every(search_x,search_y)=sum(sum(Collectivemap(x1:x2,y1:y2)));
                end
            end
            Collectivemap_every=Collectivemap_every./max(max(Collectivemap_every));
            %%
            a=imadd(Collectivemap_every,curFrame(:,:,1));
            subplot(2,2,4),imagesc(a)
            title([ 'Collective Map Frame=' num2str(i)  '   neighbor=' num2str(neighbor) '  Interval=' num2str(interval4)])
            drawnow
        end
    end
end