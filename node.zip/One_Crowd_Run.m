function [crowdCollectiveness1_frame,crowdCollectiveness2_frame,crowdCollectiveness3_frame,crowdCollectiveness4_frame,crowdCollectiveness5_frame,crowdCollectiveness6_frame]=One_Crowd_Run(XVset)
%% ȥ���ٶ�Ϊ0�ĵ�--����
%     zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
%     XVset(zeroindex,:)=[];
%%
count_frame=1;%curOrder=[];
crowdCollectiveness1_frame=[]; crowdCollectiveness2_frame=[];crowdCollectiveness3_frame=[];crowdCollectiveness4_frame=[];crowdCollectiveness5_frame=[];crowdCollectiveness6_frame=[];
%% ���ô��ļ�
%         folder=sub_dirs{idx};
%         curVideo = fullfile('video_clips', folder);
%         curClipFrameSet = dir([curVideo '\*.jpg']);
%    for i = 2:length(curClipFrameSet)
%
length_curClip=max(XVset(:, 5) );
para.K =20;%20���ھ�-KNN
para.z = 0.5/para.K ;
para.thre=0.7;%common clique

% crowdCollectiveness1=0;crowdCollectiveness2=0;crowdCollectiveness3=0;crowdCollectiveness4=0;crowdCollectiveness5=0;crowdCollectiveness6=0;
for i = 2:length_curClip
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    %         size(curX)
    %%
    if ~isempty(curX)
        %                         curOrder(count_frame) = SDP_order(curV); % average velocity measurement
        [~, crowdCollectiveness1, ~,~,~,~,~]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
        %%   exp collect    para.K =30;%20���ھ�-KNN
        [~, crowdCollectiveness2, ~, ~,~,~] = measureLannerness( curX, curV, para);
        %% common_clique
        [crowdCollectiveness3,crowdCollectiveness4,crowdCollectiveness5,crowdCollectiveness6,~] = common_clique_new_parfor_test( curX, curV, para, 1);
        %%
        crowdCollectiveness1_frame(count_frame)=crowdCollectiveness1;        crowdCollectiveness2_frame(count_frame)=crowdCollectiveness2;
        crowdCollectiveness3_frame(count_frame)=crowdCollectiveness3;        crowdCollectiveness4_frame(count_frame)=crowdCollectiveness4;
        crowdCollectiveness5_frame(count_frame)=crowdCollectiveness5;        crowdCollectiveness6_frame(count_frame)=crowdCollectiveness6;
        
        count_frame=count_frame+1
    end
end



