function [collec_0,collec_1,collec_2,collec_3,collec_4,collec_5,collec_6,collec_7,co_00]=One_SDP_Run(para,SDPpara)
%nov 25. SDP ����ʵ��. ������������������Common Clique Ч����Щ
%% initilize the self-driven particles
[curX,curVelocityDegree,XLabel,SDPpara] = SDP_initialXwithNoise(SDPpara);
keyDotIndex  = find(XLabel==1);      % the index of self-driven particles
outlierIndex = find(XLabel==-1);    % the index of randomly moving points
%% begin iteration
% figure
% set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.8]);
%%
looop=1;
crowdCollectiveness1=0;crowdCollectiveness2=0;crowdCollectiveness3=0;crowdCollectiveness4=0;
crowdCollectiveness5=0;crowdCollectiveness6=0;crowdCollectiveness7=0;
while 1
    %% update SDP model
    [nextX,nextVelocityDegree] = SDP_updateXwithOutlier(curX,curVelocityDegree,outlierIndex,SDPpara); % update SDP model
    curVelocityDegree = nextVelocityDegree;
    curX = nextX;
    curV = [cos(curVelocityDegree) sin(curVelocityDegree)];
    %% ��������--ֻ���Ƿ��������order_system
    curV_1=curV(keyDotIndex,:);
    order_system = SDP_order(curV_1);
    %% ԭʼ
    %     order_system = SDP_order(curV);
    %%
    [~, crowdCollectiveness1, ~,~,~,~,~]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
    %%
    [~, crowdCollectiveness2, ~, ~,~,~] = measureLannerness( curX, curV, para);
    %% common clique_SDP
    % % %     %     [collectivenessSet2, crowdCollectiveness2,Z2,length_i2] = common_clique( curX, curV, para);%����ģ�ͣ���ǩ���������������������
    % % %     %     [collectivenessSet3, crowdCollectiveness3,Z3,length_i3] = common_clique2( curX, curV, para);%����ģ�ͣ���ǩ�������������Ǿ��ȷֲ�����
    % % %     %     [collectivenessSet3, crowdCollectiveness3,Z3,length_i3] =     common_clique_new_old1( curX, curV, para);%���۱�׼�٣�������
    % % %     %     [crowdCollectiveness3,crowdCollectiveness4,crowdCollectiveness5,~,crowdCollectiveness6] = common_clique_new( curX, curV, para);
    %     tic-newest nov.24
%         tic
%     [crowdCollectiveness3,~,~,~,~] = common_clique_new_parfor_test( curX, curV, para ,1,1);%select:avg1,min0; compare_strategy:|A U B|1,|A|0. %ÿ����һ����,����һ��Flag.
%         toc
%     
%         tic
%     [crowdCollectiveness4,~,~,~,~] = common_clique_new_parfor_test( curX, curV, para ,0,1);%����һ�����ٸ���flag
%         toc
%% dec 09 test. J(A,B)=|A^B|/|A U B|  or J(A,B)=|A^B|/|A|

        [crowdCollectiveness3,crowdCollectiveness4] = common_clique_final( curX, curV, para , 1);

        [crowdCollectiveness5,crowdCollectiveness6] = common_clique_final( curX, curV, para , 0);
    %%
    % % %     %     subplot(3,3,3),
    % % %     %     hold off
    % % %     %     scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
    % % %     %     scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
    % % %     %     quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
    % % %     %     xlim([0 SDPpara.L])
    % % %     %     ylim([0 SDPpara.L])
    % % %     %     title(['System Order=' num2str(order_system) ', Coll=' num2str(crowdCollectiveness)  ', Coll-1=' num2str(crowdCollectiveness1) ', Coll-2=' num2str(crowdCollectiveness2)]);
    % % %     %     drawnow
    % % %     %
    % % %     %     subplot(3,3,4),hist(collectivenessSet1,20)
    % % %     %     title('Histogram of Individual Coll 1');
    % % %     %     subplot(3,3,5),hist(collectivenessSet2,20)
    % % %     %     title('Histogram of Individual Coll 2');
    %%
    collec_0(looop)=order_system;
    collec_1(looop)=crowdCollectiveness1;    collec_2(looop)=crowdCollectiveness2;
    collec_3(looop)=crowdCollectiveness3;    collec_4(looop)=crowdCollectiveness4;
    collec_5(looop)=crowdCollectiveness5;    collec_6(looop)=crowdCollectiveness6; collec_7(looop)=crowdCollectiveness7;
    
    looop=looop+1
    if looop>2
        co_1_1=corrcoef(collec_0,collec_1); co_2_2=corrcoef(collec_0,collec_2); co_3_3=corrcoef(collec_0,collec_3);
        co_4_4=corrcoef(collec_0,collec_4); co_5_5=corrcoef(collec_0,collec_5); co_6_6=corrcoef(collec_0,collec_6);co_7_7=corrcoef(collec_0,collec_7);
        
        co_1(looop)=co_1_1(1,2);co_2(looop)=co_2_2(1,2);co_3(looop)=co_3_3(1,2);%avg-cof��ƽ�����ϵ����coll:�ۼ���
        co_4(looop)=co_4_4(1,2);co_5(looop)=co_5_5(1,2);co_6(looop)=co_6_6(1,2);%avg-cof��ƽ�����ϵ����coll:�ۼ���
        co_7(looop)=co_7_7(1,2);
        %%
        %                    subplot(2,2,1),
        %                     hold off
        %                     scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
        %                     scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
        %                     quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
        %                     quiver(curX(outlierIndex,1),curX(outlierIndex,2),curV(outlierIndex,1),curV(outlierIndex,2),'r');
        %                     xlim([0 SDPpara.L])
        %                     ylim([0 SDPpara.L])
        %                     title(['System Order=' num2str(order_system) ', Collectiveness= ' num2str(crowdCollectiveness1)]);
        %                     drawnow
        % % %         % %     %     subplot(3,3,2),hist(collectivenessSet1,20)
        % % %         % %     %     title('Histogram of Individual Collectiveness1');
        %
        %                 subplot(2,2,2),
        %                 plot(collec_0,'-.ob', 'MarkerFaceColor','b','DisplayName','collec_0','YDataSource','collec_0');
        %                 hold on
        %                 plot(collec_1,'-.ok','MarkerFaceColor','k','DisplayName','collec_1','YDataSource','collec_1')
        %                 hold on
        %                 plot(collec_2,'-.om','MarkerFaceColor','m','DisplayName','collec_2','YDataSource','collec_2')
        %                 hold on
        %                 plot(collec_3,'-.or','MarkerFaceColor','r','DisplayName','collec_3','YDataSource','collec_3')
        %                 figure(gcf)
        %
        % % %         % %         subplot(3,3,3),scatter(collec_0,collec_1,'filled');title(['1, cof=  ' num2str(co_1(looop)) '1, value diff= ' num2str(sum(abs(collec_0-collec_1))) '1, coll= ' num2str(crowdCollectiveness1)]);
        % % %         % %         subplot(3,3,4),scatter(collec_0,collec_2,'filled');title(['2, cof=  ' num2str(co_2(looop)) '2, value diff= ' num2str(sum(abs(collec_0-collec_2))) '2, coll= ' num2str(crowdCollectiveness2)]);
        % % %         % %         subplot(3,3,5),scatter(collec_0,collec_3,'filled');title(['3, cof=  ' num2str(co_3(looop)) '3, value diff= ' num2str(sum(abs(collec_0-collec_3))) '3, coll= ' num2str(crowdCollectiveness3)]);
        % % %         % %         subplot(3,3,6),scatter(collec_0,collec_4,'filled');title(['4, cof=  ' num2str(co_4(looop)) '4, value diff= ' num2str(sum(abs(collec_0-collec_4))) '4, coll= ' num2str(crowdCollectiveness4)]);
        % % %         % %         subplot(3,3,7),scatter(collec_0,collec_5,'filled');title(['5, cof=  ' num2str(co_5(looop)) '5, value diff= ' num2str(sum(abs(collec_0-collec_5))) '5, coll= ' num2str(crowdCollectiveness5)]);
        % % %         % %         subplot(3,3,8),scatter(collec_0,collec_6,'filled');title(['6, cof=  ' num2str(co_6(looop)) '6, value diff= ' num2str(sum(abs(collec_0-collec_6))) '6, coll= ' num2str(crowdCollectiveness6)]);
        %
        %                 subplot(2,2,3),
        %                 plot(collec_0,'-.ob','MarkerFaceColor','b','DisplayName','collec_0','YDataSource','collec_0');
        %                 hold on
        %                 plot(collec_4,'-.om','MarkerFaceColor','b','DisplayName','collec_0','YDataSource','collec_0');
        %                 hold on
        %                 plot(collec_5,'-.or','MarkerFaceColor','r','DisplayName','collec_4','YDataSource','collec_4')
        %                 hold on
        %                 plot(collec_6,'-.ok','MarkerFaceColor','k','DisplayName','collec_5','YDataSource','collec_5')
        %                 hold on
        %                 plot(collec_7,'-.og','MarkerFaceColor','g','DisplayName','collec_6','YDataSource','collec_6')
        %                 figure(gcf)
        %
        %                 subplot(2,2,4),
        %                 plot(collec_0,'-.ob','MarkerFaceColor','b','DisplayName','collec_0','YDataSource','collec_0');
        %                 hold on
        %                 plot(collec_2,'-.om','MarkerFaceColor','m','DisplayName','collec_4','YDataSource','collec_4')
        %                 hold on
        %                 plot(collec_3,'-.or','MarkerFaceColor','r','DisplayName','collec_4','YDataSource','collec_4')
        %                 hold on
        %                 figure(gcf)
    end
    %     if norm(order_system-1)<10^(-3)
    if abs(order_system-1)<0.05
        break;
    end
    if looop==100
        break;
    end
    %%
    %         clusterIndex = collectiveMerging( Zmatrix, para ); % get clusters from Z matrix
    %         nClass=min(5,max(2,max(clusterIndex)));
    %         [WG2,WG3,WG4,WG5,rightpoint2,rightpoint3,rightpoint4,rightpoint5]=getgraph3(Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix,clusterIndex,para);
    
    %         clusterIndex3=zeros(1,size(curX,1));
    %         V3=softspectralclustering(WG2,nClass,1,0.01);
    %         label3 = litekmeans(V3,nClass,'Replicates',20);
    %         clusterIndex3(rightpoint2)=label3;
    %         [sparseness00,sparseness11]=sparseness(V3);
    %
    %         subplot(2,2,3),
    %         hold off
    %         scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
    %         scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
    %         quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
    %         xlim([0 SDPpara.L])
    %         ylim([0 SDPpara.L])
    %         title(['System Order=' num2str(order_system) ', Collectiveness=' num2str(sparseness00)]);
    %         drawnow
    %         subplot(2,2,4),hist(sparseness11,20)
    %         title('Histogram of Individual Collectiveness');
    
    %%
end
co_00=[mean(co_1),mean(co_2),mean(co_3),mean(co_4),mean(co_5),mean(co_6),mean(co_7)];