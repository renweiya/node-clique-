function PlotGraph1(points,A,titlestring)%point:fea; titlestring
A=(A>0);
num_points = size(A,1); 

if (size(A,1) ~= size(A, 2)), 
  error('Adjacency matrix is not square. ')
end

if (sum(sum(A - A') > 0.0001)), 
  warning('Adjacency matrix is not symmetric. I only plot edges in one direction.')
end

if (size(points,1) ~= num_points)
  error('Number of points does not match size of adjacency matrix.' )
end


color = 0; 
zhongjian=ceil(num_points/2);

hold all
plot(points(1:zhongjian,1), points(1:zhongjian,2), 'r.','MarkerSize',20, 'MarkerEdgeColor','b','MarkerFaceColor','b');
hold on
plot(points(zhongjian+1:num_points,1), points(zhongjian+1:num_points,2), 'r.','MarkerSize',20,'MarkerEdgeColor','g','MarkerFaceColor','g');


xx = zeros(2*num_points,1);
yy = zeros(2*num_points,1);
DiffVal=0; NumDiffVal=0;
for it= 1: num_points
  
  if (color)
  else
    indices = find(A(it,:)>0);
    NumIndices=length(indices);
    if(NumIndices>0)
      xx(1:2:2*NumIndices)=points(it,1);
      xx(2:2:2*NumIndices)=points(indices,1);
      yy(1:2:2*NumIndices)=points(it,2);
      yy(2:2:2*NumIndices)=points(indices,2);
%       plot(xx(1:2*NumIndices),yy(1:2*NumIndices),'-k','LineWidth',1);
      
      plot(xx(1:2*NumIndices),yy(1:2*NumIndices), '--r','LineWidth',0.1,'MarkerSize',0.01);
     
    end
  end

end

% plot(points(1:101,1), points(1:101,2), 'r.','MarkerSize',15, 'MarkerEdgeColor','b','MarkerFaceColor','b');
% hold on
% plot(points(102:202,1), points(102:202,2), 'r.','MarkerSize',15,'MarkerEdgeColor','g','MarkerFaceColor','g');


title(titlestring)
axis tight

if (color)
  colormap(colors)
  colorbar('YTick',[1,60],'YTickLabel',...
           {num2str(amin,'%2.2f'), num2str(amax,'%2.2f')})
end