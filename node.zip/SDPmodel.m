clear
clc
addpath('util\');addpath('Algorithms\');addpath('data\');addpath('gactoolbox\');

%% parameters of Self-Driven Particles
SDPpara.nPoint =400;         %number of particles
SDPpara.L = 7;                %size of the ground
SDPpara.R = 1;                %size of the interaction radius
SDPpara.noise = 0.00;         %random perturbation
SDPpara.velocity = 0.03;      %velocity value
SDPpara.outlierRatio = 0;     %outlier ratio

%% parameters of collectiveness measurement
para.K =20;
para.z = 0.5/para.K ;
para.upperBound = para.K*para.z/(1-para.K*para.z);
para.threshold = 0.4*para.z/(1-para.K*para.z);

%% initilize the self-driven particles
[curX,curVelocityDegree,XLabel,SDPpara] = SDP_initialXwithNoise(SDPpara);
keyDotIndex = find(XLabel==1);      % the index of self-driven particles
outlierIndex = find(XLabel==-1);    % the index of randomly moving points
%% begin iteration
% figure
% set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.8]);
looop=1;
while 1
    [nextX,nextVelocityDegree] = SDP_updateXwithOutlier(curX,curVelocityDegree,XLabel,SDPpara); % update SDP model
    curVelocityDegree = nextVelocityDegree;
    curX = nextX;
    curV = [cos(curVelocityDegree) sin(curVelocityDegree)];
    order_system = SDP_order(curV); % compute the average velocty
    
    %     [collectivenessSet, crowdCollectiveness, Zmatrix] = measureCollectiveness( curX, curV, para); % compute collectiveness
    [collectivenessSet, crowdCollectiveness, Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
    
    %%
%     subplot(3,3,1),
%     hold off
%     scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
%     scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
%     quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
%     xlim([0 SDPpara.L])
%     ylim([0 SDPpara.L])
%     title(['System Order=' num2str(order_system) ', Collectiveness= ' num2str(crowdCollectiveness)]);
%     drawnow
%     subplot(3,3,2),hist(collectivenessSet,20)
%     title('Histogram of Individual Collectiveness');
    %%
    
    
    [collectivenessSet1, crowdCollectiveness1, collectivenessSet2, crowdCollectiveness2,Z1,Z2] = measureLannerness( curX, curV, para);
    
    %     collectivenessSet1=max(collectivenessSet1,0);
    %     collectivenessSet2=max(collectivenessSet2,0);
%         crowdCollectiveness1=exp(crowdCollectiveness1)
%         crowdCollectiveness2=log(crowdCollectiveness2)
    
%     subplot(3,3,3),
%     hold off
%     scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
%     scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
%     quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
%     xlim([0 SDPpara.L])
%     ylim([0 SDPpara.L])
%     title(['System Order=' num2str(order_system) ', Collectiveness=' num2str(crowdCollectiveness)  ', Collectiveness1=' num2str(crowdCollectiveness1) ', Collectiveness2=' num2str(crowdCollectiveness2)]);
%     drawnow
%     
%     subplot(3,3,4),hist(collectivenessSet1,20)
%     title('Histogram of Individual Collectiveness');
%     subplot(3,3,5),hist(collectivenessSet2,20)
%     title('Histogram of Individual Collectiveness');
    %%
    collec_1(looop)=order_system;
    collec_2(looop)=crowdCollectiveness;
    collec_3(looop)=crowdCollectiveness1;
    collec_4(looop)=crowdCollectiveness2;
    looop=looop+1
    if looop>2
        co_1_1=corrcoef(collec_1,collec_2); co_2_2=corrcoef(collec_1,collec_3); co_3_3=corrcoef(collec_1,collec_4);
        co_1(looop)=co_1_1(1,2);co_2(looop)=co_2_2(1,2);co_3(looop)=co_3_3(1,2);
%         subplot(3,3,6),scatter(collec_1,collec_2,'filled'); title(['1, cofficient= ' num2str(co_1(looop)) '1, mean cofficient= ' num2str(mean(co_1))]);
%         subplot(3,3,7),scatter(collec_1,collec_3,'filled');title(['2, cofficient=  ' num2str(co_2(looop)) '1, mean cofficient= ' num2str(mean(co_2))]);
%         subplot(3,3,8),scatter(collec_1,collec_4,'filled');title(['3, cofficient=  ' num2str(co_3(looop)) '1, mean cofficient= ' num2str(mean(co_3))]);
    end
    if norm(order_system-1)<10^(-3)
        break;
    end
    if looop==100
        break;
    end
    %%
%         clusterIndex = collectiveMerging( Zmatrix, para ); % get clusters from Z matrix
%         nClass=min(5,max(2,max(clusterIndex)));
%         [WG2,WG3,WG4,WG5,rightpoint2,rightpoint3,rightpoint4,rightpoint5]=getgraph3(Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix,clusterIndex,para);
    
%         clusterIndex3=zeros(1,size(curX,1));
%         V3=softspectralclustering(WG2,nClass,1,0.01);
%         label3 = litekmeans(V3,nClass,'Replicates',20);
%         clusterIndex3(rightpoint2)=label3;
%         [sparseness00,sparseness11]=sparseness(V3);
        %
%         subplot(2,2,3),
%         hold off
%         scatter(curX(keyDotIndex,1),curX(keyDotIndex,2),'b'),hold on
%         scatter(curX(outlierIndex,1),curX(outlierIndex,2),'r'),hold on
%         quiver(curX(keyDotIndex,1),curX(keyDotIndex,2),curV(keyDotIndex,1),curV(keyDotIndex,2),'b');
%         xlim([0 SDPpara.L])
%         ylim([0 SDPpara.L])
%         title(['System Order=' num2str(order_system) ', Collectiveness=' num2str(sparseness00)]);
%         drawnow
%         subplot(2,2,4),hist(sparseness11,20)
%         title('Histogram of Individual Collectiveness');
end
mean(co_1)
mean(co_2)
mean(co_3)
