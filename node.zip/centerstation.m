%% Measuring collectiveness at each frame of a video
%% center station
% Mar.28 2013, Bolei Zhou
clear
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
curVideo = 'sample_video\';
curTrkName = 'klt_3000_20_trk.txt';
%%
do_cluster=0;
do_map=2;
%% Collectiveness parameter
para.K = 20;%20���ھ�-KNN
para.z = 0.5/para.K ;
para.upperBound = para.K*para.z/(1-para.K*para.z);
para.threshold = 0.6*para.z/(1-para.K*para.z);

%%
curClipFrameSet = dir([curVideo '\*.jpg']);
curTrks = readTraks([curVideo '\' curTrkName]);
[XVset] = trk2XV(curTrks, 1, 2); % transform trajectories into point set
if do_cluster==1
    figure
end
Map=[];
curFrame = imread([curVideo '\' curClipFrameSet(1).name]);
[Lm,Ln,~]=size(curFrame);
for i = 1:length(curClipFrameSet)
    i
    curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
    curFrame = im2double(curFrame);
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    curOrder = SDP_order(curV); % average velocity measurement
    [collectivenessSet, crowdCollectiveness, Zmatrix] = measureCollectiveness( curX, curV, para);%crowd collectiveness
    %% collective map
    Map(:,:,i)=getcollectiveMap(curX,collectivenessSet,Lm,Ln);
    %% threshold clustering
    clusterIndex = collectiveMerging( Zmatrix, para ); % get clusters from Z matrix
    if do_cluster==1
        %% threshold
        WG = Zmatrix > para.threshold;%0-1ͼ�����Գ�
        % or
        %         WG=Zmatrix;WG(Zmatrix<para.threshold)=0;%weight ͼ
        %% �Գƻ�
        WG=max(WG,WG');
        noisepoint=find(sum(WG,2)==0);%������
        rightpoint=find(sum(WG,2)~=0);
        %% ȥ��������
        WG(noisepoint,:)=[];
        WG(:,noisepoint)=[];
        WG=real(WG);
        %%
        nClass=min(3,max(2,max(clusterIndex)));
        %     nClass=2;
        if length(noisepoint)<size(curX,1)
            %% Ncut
            clusterIndex2=zeros(1,size(curX,1));
            V2=ncutW(WG,nClass);
            label2 = litekmeans(V2,nClass,'Replicates',20);
            clusterIndex2(rightpoint)=label2;
            %% CAC
            clusterIndex3=zeros(1,size(curX,1));
            V3=softspectralclustering(WG,nClass,1,0.01,1);
            label3 = litekmeans(V3,nClass,'Replicates',20);
            clusterIndex3(rightpoint)=label3;
            %% Normal_Ncut or CAC
            clusterIndex4=zeros(1,size(curX,1));
            V4=softspectralclustering(WG,nClass,1,1,0);
            %         V4=normalizedlaplacian(WG,nClass);
            label4 = litekmeans(V4,nClass,'Replicates',20);
            clusterIndex4(rightpoint)=label4;
        else
            clusterIndex2=zeros(1,size(curX,1));
            clusterIndex3=zeros(1,size(curX,1));
            clusterIndex4=zeros(1,size(curX,1));
        end
       %% draw
       drawcluster.m;
    end
end

%% ȷ�������
%         W=WG;
%         D=diag(sum(W));
%         D1=diag((sum(W)).^(-0.5));
%         L=D1*(D-W)*D1;
%         C=full(L);[vectors,values]=eig(C);values=sum(values);
%         margin=[];
%         for tempj=1:length(values)-1
%             margin(tempj)=abs(values(tempj+1)-values(tempj));
%         end
%         [m,nClass1]=max(margin)