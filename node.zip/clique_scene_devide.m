%% Measuring collectiveness at each frame of a video
clear; clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
clip_dir = 'video_clips';
% sub_dirs = dir(clip_dir);
% sub_dirs = sub_dirs(3:end);
% b_dir = [sub_dirs.isdir];
% sub_dirs = {sub_dirs(b_dir).name};
%%
% collectivenessClips=cell2mat(collectivenessData(2,:));
% velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
Human_table=sum(GT_human);
Human_table_mod=mode(GT_human);%����
%%
% folder_name = uigetdir(clip_dir);
% [root, folder] = fileparts(folder_name);
% idx_temp = strcmp(sub_dirs, folder);%��һ���ļ�list���ҵ�һ���ļ���
% idx=find(idx_temp);
%%
% select_idx=randperm(413);
% idx=select_idx(1)

idx=17
% used: 212,303,323,17
% bad 256, 10 frame

score=Human_table(idx)
score1=Human_table_mod(idx)
%%
% ����idx=77,96,212,243,273.
% ����idx=5-,53, 80-,
% ����idx=315,346-
% ����idx=167-,197-

% clustering good idx=49,52,250,255
% idx=81,146,153,184,187
% idx=215,225,255,261,273,342,348,364,404
folder=sub_dirs{idx}
%%
curVideo = fullfile('video_clips', folder);

% curVideo = 'realcrowd\';
curTrkName = 'klt_3000_10_trk.txt';
% curTrkName = 'klt_3000_10_trk_filt.txt';
%%
do_cluster=1;
%%
curClipFrameSet = dir([curVideo '\*.jpg']);
curTrks = readTraks([curVideo '\' curTrkName]);
[XVset] = trk2XV(curTrks, 1, 2); %��Ҫһ�д���-�켣���� % transform trajectories into point set
%% ȥ���ٶ�Ϊ0�ĵ�--����
% % zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
% % XVset(zeroindex,:)=[];
%%
% if do_cluster==1
%     figure
%     set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.8]);
% end


Map=[];Map1=[];
curFrame = imread([curVideo '\' curClipFrameSet(1).name]);
%%
% for i = 2:length(curClipFrameSet)
for i = 10:10
    curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
    curFrame = im2double(curFrame);
    [Lm,Ln,Lk]=size(curFrame);
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    size(curX)
    
    figure;imshow(curFrame),hold off
    %%
    %     curOrder = SDP_order(curV); % average velocity measurement
    tic
    para.K=20;para.z = 0.5/para.K ;para.upperBound = para.K*para.z/(1-para.K*para.z);para.threshold = 0.6*para.z/(1-para.K*para.z);
    [~, ~, Zinv,~,~,~,~]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
    toc
    tic
    Zexp.K=20;
    [~, ~, ~, ~,Zexp,~] = measureLannerness( curX, curV, Zexp);
    toc
    tic
    select=1;para.thre=0.7;
    [~,~,Z_one,Z_second] = common_clique_finaldraw( curX, curV, para , select);
    toc
    %% collective map
    %     Map(:,:,i) =getcollectiveMap(curX,collectivenessSet1,Lm,Ln);
    %% threshold clustering
    %     clusterIndex = collectiveMerging( Zinv,  para ); % get clusters from Z matrix
    
    %%
    para.threshold=0.03;%0.03
    clusterIndex1 = collectiveMerging_clique(Zinv, para,1);%�Ա࣬much faster than above
    %%
    Zexppara.threshold=10^(-5);%10^(-5);%10^(-5)
    clusterIndex2 = collectiveMerging_clique(Zexp, Zexppara,1);%�Ա࣬much faster than above
    
    
    NCLpara.threshold=0.4;
    
    clusterIndex3 = collectiveMerging_clique(Z_one, NCLpara,1);%�Ա࣬much faster than above
    clusterIndex4 = collectiveMerging_clique(Z_second, NCLpara,1);%�Ա࣬much faster than above
    %% draw
    draw_clique_learning;
end


