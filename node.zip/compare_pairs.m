function right_percent=compare_pairs(collec_0,collec_1)
% collec_1=collec_3;
%�����ȽϾۼ��ȣ�ͳ���ж���ȷ��.collect:��ʵֵ.
[m,n]=size(collec_0);
N=max(m,n);
judge_pair=zeros((N^2-N)/2,1);
count=1;
for i=1:N-1
    for j=i+1:N
        if collec_0(i)==collec_0(j)&&collec_1(i)==collec_1(j)
            judge_pair(count)=1;
        end
        if collec_0(i)>collec_0(j)&&collec_1(i)>collec_1(j)
            judge_pair(count)=1;
        end
        if collec_0(i)<collec_0(j)&&collec_1(i)<collec_1(j)
            judge_pair(count)=1;
        end
        count=count+1;
    end
end
right_percent= sum(judge_pair)/((N^2-N)/2)