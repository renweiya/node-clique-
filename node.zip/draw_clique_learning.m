%draw_clique_learning
%% draw
Shape_N={'o','s','d','>','p','<','h','v'};
Color_N=max(max(max(clusterIndex1),max(clusterIndex2)),max(max(clusterIndex3),max(clusterIndex4)));
[max(clusterIndex1),max(clusterIndex2),max(clusterIndex3),max(clusterIndex4)]
C_color=hsv(Color_N);%
% a=randperm(Color_N);
% C_color=C_color(a,:);

%% 1     hold off,
curFrame0=curFrame;
if Lk==3
    %     curFrame0=rgb2gray(curFrame);
end
subplot(2,2,1),imshow(curFrame0),hold on
%%%%%%%%%% plot points with different clusters at each frame
% scatter(curX(:,1),curX(:,2),'+r')
% quiver(curX(:,1),curX(:,2),curV(:,1),curV(:,2),'y'),
for j = 1:max(clusterIndex1)
    curClusterIndex1=find(clusterIndex1==j);jj=j;
    if jj>8
        j_rand=randperm(8);
        jj=j_rand(1);
    end
    scatter(curX(curClusterIndex1,1),curX(curClusterIndex1,2),[],C_color(j,:),'filled',Shape_N{jj}),
end
title(['No.=' num2str( size(find(clusterIndex1 ~=0),2)) ',k=' num2str(max(clusterIndex1))  ',Scores=' num2str(Human_table(idx))  ])
drawnow
%% 2    hold off,
subplot(2,2,2),imshow(curFrame0),hold on
% scatter(curX(:,1),curX(:,2),'+r')
% quiver(curX(:,1),curX(:,2),curV(:,1),curV(:,2),'y'),
for j = 1:max(clusterIndex2)
    curClusterIndex2=find(clusterIndex2==j);
    jj=j;
    if jj>8
        j_rand=randperm(8);
        jj=j_rand(1);
    end
    scatter(curX(curClusterIndex2,1),curX(curClusterIndex2,2),[],C_color(j,:),'filled',Shape_N{jj}),
end
title([ 'N=' num2str( size(find(clusterIndex2 ~=0),2)) ',k=' num2str(max(clusterIndex2)) ])
drawnow

%% 3    hold off,
subplot(2,2,3),imshow(curFrame0),hold on
% scatter(curX(:,1),curX(:,2),'+r')
% quiver(curX(:,1),curX(:,2),curV(:,1),curV(:,2),'y'),
for j = 1:max(clusterIndex3)
    curClusterIndex3=find(clusterIndex3==j); jj=j;
    if jj>8
        j_rand=randperm(8);
        jj=j_rand(1);
    end
    scatter(curX(curClusterIndex3,1),curX(curClusterIndex3,2),[],C_color(j,:),'filled',Shape_N{jj}),
    %     scatter(curX(curClusterIndex3,1),curX(curClusterIndex3,2),[],C_color(j,:),Shape_N{jj}),
end
title([  'N=' num2str( size(find(clusterIndex3 ~=0),2)) ',Frames=' num2str(i) ',k=' num2str(max(clusterIndex3)) ])
drawnow
%% 4    hold off,
subplot(2,2,4),imshow(curFrame0),hold on
% scatter(curX(:,1),curX(:,2),'+r')
% quiver(curX(:,1),curX(:,2),curV(:,1),curV(:,2),'y'),
for j = 1:max(clusterIndex4)
    curClusterIndex4=find(clusterIndex4==j); jj=j;
    if jj>8
        j_rand=randperm(8);
        jj=j_rand(1);
    end
    scatter(curX(curClusterIndex4,1),curX(curClusterIndex4,2),[],C_color(j,:),'filled',Shape_N{jj}),
end
% title([ 'CAC2000---Frames=' num2str(i) ',Clusters=' num2str(max(clusterIndex4)) ])
% title([  'idx=' num2str( idx)  ',Points=' num2str( size(find(clusterIndex4 ~=0),2)) 'Frames=' num2str(i) ',k=' num2str(max(clusterIndex4)) ',variate3=' num2str(variate_forsparse4) ',Sparse=' num2str(msparse4) ',Collect=' num2str( (2*variate_forsparse4*sqrt(msparse4)))])
title([  'idx=' num2str( idx)  ',Points=' num2str( size(find(clusterIndex4 ~=0),2)) 'Frames=' num2str(i) ',k=' num2str(max(clusterIndex4)) ])

% end