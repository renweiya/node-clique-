%% Measuring collectiveness at each frame of a video
clear
clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
clip_dir = 'video_clips';
%%
collectivenessClips=cell2mat(collectivenessData(2,:));
velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
%%
Human_table=sum(GT_human);
Human_table_mod=mode(GT_human);
%%
%% Collectiveness parameter
% para.K = 20;%20���ھ�-KNN
% para.z = 0.5/para.K ;
% para.upperBound = para.K*para.z/(1-para.K*para.z);
% para.threshold = 0.6*para.z/(1-para.K*para.z);
%%
crowdCollectiveness_total=[];crowdCollectiveness1_total=[];
load XVset_all.mat
doallloop=1;
for idx=1:413
    doallloop
    XVset=XVset_all{idx};
    %% ȥ���ٶ�Ϊ0�ĵ�--����
    %     zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
    %     XVset(zeroindex,:)=[];
    %%
    count_frame=1;crowdCollectiveness_frame=[]; crowdCollectiveness1_frame=[];curOrder=[];
    %%
    folder=sub_dirs{idx};
    curVideo = fullfile('video_clips', folder);
    curClipFrameSet = dir([curVideo '\*.jpg']);
    for i = 2:length(curClipFrameSet)
%      for i =2:11
        curIndex = find(XVset(:, 5) == i);
        curX = XVset(curIndex,1:2);  %����
        curV = XVset(curIndex,3:4);  %�ٶ�
        %%
        if ~isempty(curX)
            %                         curOrder(count_frame) = SDP_order(curV); % average velocity measurement
            para.K =15;%20���ھ�-KNN
            para.z = 0.5/para.K ;
            [~, crowdCollectiveness, ~,~,~,~,~]  = measureCollectiveness( curX, curV, para);%crowd collectiveness

%             para.K =30;%20���ھ�-KNN
            [~, crowdCollectiveness1, ~, ~,~,~] = measureLannerness( curX, curV, para);
            
            crowdCollectiveness_frame (count_frame)=crowdCollectiveness;
            crowdCollectiveness1_frame(count_frame)=crowdCollectiveness1;
            count_frame=count_frame+1;
        end
    end
    Human_table(1:doallloop);
    %     crowdCollectiveness_curOrder (doallloop)=mean(curOrder);
    crowdCollectiveness_total (doallloop)=mean(crowdCollectiveness_frame);
    crowdCollectiveness1_total(doallloop)=mean(crowdCollectiveness1_frame);
    %     if doallloop>2
    % % %         %         co_1_1=corrcoef(crowdCollectiveness_total,Human_table(1:doallloop)); co_2_2=corrcoef(crowdCollectiveness1_total,Human_table(1:doallloop));
    % % %         %         co_1=co_1_1(1,2)
    % % %         %         co_2=co_2_2(1,2)
    %
%     [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all(crowdCollectiveness_total,Human_table,Human_table_mod,1);
%     acu=[acu_high_low,acu_high_media,acu_media_low]
%     [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all(crowdCollectiveness1_total,Human_table,Human_table_mod,1);
%     acu1=[acu_high_low1,acu_high_media1,acu_media_low1]
%     %
%     [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all(crowdCollectiveness_total,Human_table,Human_table_mod,2);
%     acu0=[acu_high_low,acu_high_media,acu_media_low]
%     [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all(crowdCollectiveness1_total,Human_table,Human_table_mod,2);
%     acu01=[acu_high_low1,acu_high_media1,acu_media_low1]
    %         disp('norm SME')
    [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_1(crowdCollectiveness_total,Human_table,Human_table_mod,1);
    acu=[acu_high_low,acu_high_media,acu_media_low]
    [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_1(crowdCollectiveness1_total,Human_table,Human_table_mod,1);
    acu1=[acu_high_low1,acu_high_media1,acu_media_low1]
    
%     [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_1(crowdCollectiveness_total,Human_table,Human_table_mod,2);
%     acu0=[acu_high_low,acu_high_media,acu_media_low]
%     [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_1(crowdCollectiveness1_total,Human_table,Human_table_mod,2);
%     acu01=[acu_high_low1,acu_high_media1,acu_media_low1]
    %
    %         disp('norm SME  svm')
    %             [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_2(crowdCollectiveness_total,Human_table,Human_table_mod,1);
    %             acu0=[acu_high_low,acu_high_media,acu_media_low]
    %             [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_2(crowdCollectiveness1_total,Human_table,Human_table_mod,1);
    %             acu01=[acu_high_low1,acu_high_media1,acu_media_low1]
    %     %
    %             [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_2(crowdCollectiveness_total,Human_table,Human_table_mod,2);
    %             acu0=[acu_high_low,acu_high_media,acu_media_low]
    %             [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_2(crowdCollectiveness1_total,Human_table,Human_table_mod,2);
    %             acu01=[acu_high_low1,acu_high_media1,acu_media_low1]
    %     end
    doallloop=doallloop+1;
end
% co_1_1=corrcoef(crowdCollectiveness_total,Human_table); co_2_1=corrcoef(crowdCollectiveness1_total,Human_table);
%
% co_1_2=corrcoef(crowdCollectiveness_total,Human_table_mod); co_2_2=corrcoef(crowdCollectiveness1_total,Human_table_mod);
%
% co_11=co_1_1(1,2)
% co_21=co_2_1(1,2)
%
% co_12=co_1_2(1,2)
% co_22=co_2_2(1,2)

% co_1_1=corrcoef(crowdCollectiveness_total,crowdCollectiveness1_total)
% score_all=Human_table(idx);
% collectivenessClips(idx)
