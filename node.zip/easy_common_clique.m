%% Measuring collectiveness at each frame of a video
clear
clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
if matlabpool('size')==0
    matlabpool open
else
    disp('parfor already initialized')
end
% matlabpool close
%%
% clip_dir = 'video_clips';
%%
collectivenessClips=cell2mat(collectivenessData(2,:));
velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
%%
Human_table=sum(GT_human);
Human_table_mod=mode(GT_human);%����
%% Collectiveness parameter
para.K = 20;%20���ھ�-KNN
para.z = 0.5/para.K ;
% para.upperBound = para.K*para.z/(1-para.K*para.z);
% para.threshold = 0.6*para.z/(1-para.K*para.z);
%%
para.thre=0.7;
%%
crowdCollectiveness1_total=[];crowdCollectiveness2_total=[];
crowdCollectiveness3_total=[];crowdCollectiveness4_total=[];
crowdCollectiveness5_total=[];
crowdCollectiveness1=0;crowdCollectiveness2=0;crowdCollectiveness3=0;crowdCollectiveness4=0;crowdCollectiveness5=0;crowdCollectiveness6=0;
load XVset_all.mat
doallloop=1;
select=1;
for idx=1:413 %%%%%�Ķ�1
    doallloop
    idx
    XVset=XVset_all{idx};
    %% ȥ���ٶ�Ϊ0�ĵ�--����--%%% �Ķ�2
%         zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
%         XVset(zeroindex,:)=[];
    %%
    count_frame=1;%curOrder=[];
    crowdCollectiveness1_frame=[];crowdCollectiveness2_frame=[];crowdCollectiveness3_frame=[];
    crowdCollectiveness4_frame=[];crowdCollectiveness5_frame=[];crowdCollectiveness6_frame=[];
    %% ���ô��ļ�
%     folder=sub_dirs{idx};
%     curVideo = fullfile('video_clips', folder);
%     curClipFrameSet = dir([curVideo '\*.jpg']);
%     for i = 2:length(curClipFrameSet)

    length_curClip=max(XVset(:, 5) );
    for i = 2:length_curClip
        curIndex = find(XVset(:, 5) == i);
        curX = XVset(curIndex,1:2);  %����
        curV = XVset(curIndex,3:4);  %�ٶ�
        %%
        if ~isempty(curX)
            curOrder(count_frame) = SDP_order(curV); % average velocity measurement
            %% inv collect
%             [~, crowdCollectiveness1, ~,~,~,~,~]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
            %%   exp collect    para.K =30;%20���ھ�-KNN
%             [~, crowdCollectiveness2, ~, ~,~,~] = measureLannerness( curX, curV, para);
            %% common_clique
            [crowdCollectiveness3,crowdCollectiveness4] = common_clique_final( curX, curV, para , select);
%             crowdCollectiveness3 = common_clique_new_parfor_test( curX, curV, para,1,1);
            %%
            crowdCollectiveness1_frame(count_frame)=crowdCollectiveness1;        crowdCollectiveness2_frame(count_frame)=crowdCollectiveness2;
            crowdCollectiveness3_frame(count_frame)=crowdCollectiveness3;        crowdCollectiveness4_frame(count_frame)=crowdCollectiveness4;
            crowdCollectiveness5_frame(count_frame)=crowdCollectiveness5;        crowdCollectiveness6_frame(count_frame)=crowdCollectiveness6;
            
%             disp([Human_table(idx),crowdCollectiveness1,crowdCollectiveness2,crowdCollectiveness3,crowdCollectiveness4,crowdCollectiveness5,crowdCollectiveness6])
            
            count_frame=count_frame+1;
        end
    end
    curOrder_total(doallloop)=mean(curOrder);
    
    crowdCollectiveness1_total(doallloop)=mean(crowdCollectiveness1_frame);    crowdCollectiveness2_total(doallloop)=mean(crowdCollectiveness2_frame);
    crowdCollectiveness3_total(doallloop)=mean(crowdCollectiveness3_frame);    crowdCollectiveness4_total(doallloop)=mean(crowdCollectiveness4_frame);
    crowdCollectiveness5_total(doallloop)=mean(crowdCollectiveness5_frame);    crowdCollectiveness6_total(doallloop)=mean(crowdCollectiveness6_frame);
    %% �ָ�
%         [acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_1(crowdCollectiveness1_total,Human_table,Human_table_mod,1);%acuracy_for_all,acuracy_for_all2:norm SME  svm.
%         acu1=[acu_high_low1,acu_high_media1,acu_media_low1]
%     
%         [acu_high_low2,acu_high_media2,acu_media_low2]=acuracy_for_all_1(crowdCollectiveness2_total,Human_table,Human_table_mod,1);
%         acu2=[acu_high_low2,acu_high_media2,acu_media_low2]
%     
%         [acu_high_low3,acu_high_media3,acu_media_low3]=acuracy_for_all_1(crowdCollectiveness3_total,Human_table,Human_table_mod,1);
%         acu3=[acu_high_low3,acu_high_media3,acu_media_low3]
%     
%         [acu_high_low4,acu_high_media4,acu_media_low4]=acuracy_for_all_1(crowdCollectiveness4_total,Human_table,Human_table_mod,1);
%         acu4=[acu_high_low4,acu_high_media4,acu_media_low4]
%     
%         [acu_high_low5,acu_high_media5,acu_media_low5]=acuracy_for_all_1(crowdCollectiveness5_total,Human_table,Human_table_mod,1);
%         acu5=[acu_high_low5,acu_high_media5,acu_media_low5]
%     
%         [acu_high_low6,acu_high_media6,acu_media_low6]=acuracy_for_all_1(crowdCollectiveness6_total,Human_table,Human_table_mod,1);
%         acu6=[acu_high_low6,acu_high_media6,acu_media_low6]
    %%
    doallloop=doallloop+1;
end
% co_1_1=corrcoef(crowdCollectiveness1_total,Human_table); co_2_1=corrcoef(crowdCollectiveness2_total,Human_table);
% co_3_1=corrcoef(crowdCollectiveness3_total,Human_table); co_4_1=corrcoef(crowdCollectiveness4_total,Human_table);
% co_5_1=corrcoef(crowdCollectiveness5_total,Human_table); co_6_1=corrcoef(crowdCollectiveness6_total,Human_table);

% co_1_2=corrcoef(crowdCollectiveness1_total,Human_table_mod); co_2_2=corrcoef(crowdCollectiveness2_total,Human_table_mod);
%
% co_11=co_1_1(1,2)
% co_21=co_2_1(1,2)
% co_31=co_3_1(1,2)
% co_41=co_4_1(1,2)
% co_51=co_5_1(1,2)
% co_61=co_6_1(1,2)

% Human_table;
% collectivenessClips%����Z_inv������ƵƬ�εľۼ���
% velocityOrderClips %���ӵ��ٶ�
%% ����
%     Human_table(1:doallloop);
%     high=(Human_table>15)+(Human_table==15);  media=(Human_table<15).*(Human_table>5); low=(Human_table<5)+(Human_table==5);
%     high=logical(high);media=logical(media);low=logical(low);