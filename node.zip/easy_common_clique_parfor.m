%% Measuring collectiveness at each frame of a video
% parfor �ʼǱ�ʵ������
clear
clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
if matlabpool('size')==0
    matlabpool open
else
    disp('parfor already initialized')
end
% matlabpool close
%%
% clip_dir = 'video_clips';
%%
collectivenessClips=cell2mat(collectivenessData(2,:));
velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
%%
Human_table=sum(GT_human);
Human_table_mod=mode(GT_human);
%%
%% Collectiveness parameter
% para.K = 20;%20���ھ�-KNN
% para.z = 0.5/para.K ;
% para.upperBound = para.K*para.z/(1-para.K*para.z);
% para.threshold = 0.6*para.z/(1-para.K*para.z);
%%
crowdCollectiveness1_total=zeros(1,413);crowdCollectiveness2_total=zeros(1,413);
crowdCollectiveness3_total=zeros(1,413);crowdCollectiveness4_total=zeros(1,413);
crowdCollectiveness5_total=zeros(1,413);crowdCollectiveness6_total=zeros(1,413);

load XVset_all.mat

for idx=1:413 %parfor
    idx
    XVset=XVset_all{idx};

    % idx ʱ��������һ��ʵ��
    [crowdCollectiveness1_frame,crowdCollectiveness2_frame,crowdCollectiveness3_frame,crowdCollectiveness4_frame,crowdCollectiveness5_frame,crowdCollectiveness6_frame]=One_Crowd_Run(XVset);
    
    disp([Human_table(idx),mean(crowdCollectiveness1_frame),mean(crowdCollectiveness2_frame),mean(crowdCollectiveness3_frame),mean(crowdCollectiveness4_frame),mean(crowdCollectiveness5_frame),mean(crowdCollectiveness6_frame)])
    
    crowdCollectiveness1_total(idx)=mean(crowdCollectiveness1_frame);    crowdCollectiveness2_total(idx)=mean(crowdCollectiveness2_frame);
    crowdCollectiveness3_total(idx)=mean(crowdCollectiveness3_frame);    crowdCollectiveness4_total(idx)=mean(crowdCollectiveness4_frame);
    crowdCollectiveness5_total(idx)=mean(crowdCollectiveness5_frame);    crowdCollectiveness6_total(idx)=mean(crowdCollectiveness6_frame);
end

[acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_1(crowdCollectiveness1_total,Human_table,Human_table_mod,1);
acu1=[acu_high_low1,acu_high_media1,acu_media_low1]

[acu_high_low2,acu_high_media2,acu_media_low2]=acuracy_for_all_1(crowdCollectiveness2_total,Human_table,Human_table_mod,1);
acu2=[acu_high_low2,acu_high_media2,acu_media_low2]

[acu_high_low3,acu_high_media3,acu_media_low3]=acuracy_for_all_1(crowdCollectiveness3_total,Human_table,Human_table_mod,1);
acu3=[acu_high_low3,acu_high_media3,acu_media_low3]

[acu_high_low4,acu_high_media4,acu_media_low4]=acuracy_for_all_1(crowdCollectiveness4_total,Human_table,Human_table_mod,1);
acu4=[acu_high_low4,acu_high_media4,acu_media_low4]

[acu_high_low5,acu_high_media5,acu_media_low5]=acuracy_for_all_1(crowdCollectiveness5_total,Human_table,Human_table_mod,1);
acu5=[acu_high_low5,acu_high_media5,acu_media_low5]

[acu_high_low6,acu_high_media6,acu_media_low6]=acuracy_for_all_1(crowdCollectiveness6_total,Human_table,Human_table_mod,1);
acu6=[acu_high_low6,acu_high_media6,acu_media_low6]
% co_1_1=corrcoef(crowdCollectiveness1_total,Human_table); co_2_1=corrcoef(crowdCollectiveness2_total,Human_table);
% co_3_1=corrcoef(crowdCollectiveness3_total,Human_table); co_4_1=corrcoef(crowdCollectiveness4_total,Human_table);
% co_5_1=corrcoef(crowdCollectiveness5_total,Human_table); co_6_1=corrcoef(crowdCollectiveness6_total,Human_table);

% co_1_2=corrcoef(crowdCollectiveness1_total,Human_table_mod); co_2_2=corrcoef(crowdCollectiveness2_total,Human_table_mod);
%
% co_11=co_1_1(1,2)
% co_21=co_2_1(1,2)
% co_31=co_3_1(1,2)
% co_41=co_4_1(1,2)
% co_51=co_5_1(1,2)
% co_61=co_6_1(1,2)

% Human_table;
% collectivenessClips%����Z_inv������ƵƬ�εľۼ���
% velocityOrderClips %���ӵ��ٶ�
%% ����
%     Human_table(1:doallloop);
%     high=(Human_table>15)+(Human_table==15);  media=(Human_table<15).*(Human_table>5); low=(Human_table<5)+(Human_table==5);
%     high=logical(high);media=logical(media);low=logical(low);
