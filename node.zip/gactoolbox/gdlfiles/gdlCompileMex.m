
mex -O gdlInitAffinityTable_c.cpp gdlComputeAffinity.cpp
mex -O gdlInitAffinityTable_knn_c.cpp gdlComputeAffinity.cpp
mex -O gdlAffinity_c.cpp gdlComputeAffinity.cpp
mex -O gdlDirectedAffinity_c.cpp gdlComputeDirectedAffinity.cpp
mex -O gdlDirectedAffinity_batch_c.cpp gdlComputeDirectedAffinity.cpp