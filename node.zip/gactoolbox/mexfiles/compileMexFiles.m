
mex -O gacLlinks_c.cpp
mex -O gacOnelink_c.cpp
mex -O gacPartial_sort.cpp
mex -O gacPartialMin_knn_c.cpp
mex -O gacPartialMin_triu_c.cpp