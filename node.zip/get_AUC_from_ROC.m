function [AUC,auc]=get_AUC_from_ROC(a, b)
%a FPR
%b TPR

AUC=-trapz(a,b);

[x2,inds]=sort(a);
x2=[x2,1];
y2=b(inds);
y2=[y2,1];
xdiff=diff(x2);
xdiff=[x2(1),xdiff];
acu1=sum(y2.*xdiff);
acu2=sum([0,y2([1:end-1])].*xdiff);
auc=mean([acu1,acu2]);
