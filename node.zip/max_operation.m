function AB=max_operation(A,B)
A=double(A);B=double(B);
[m,n]=size(A);
for i=1:m
    for j=1:m
%         dot_A=find(A(i,:)>0);
%         dot_B=find(B(:,j)>0);
%         dot_AB=intersect(dot_A,dot_B)
%         if  ~isempty(dot_AB)
% (A(i, dot_AB).*(B( dot_AB,j)'))
%             AB(i,j)=mean(A(i, dot_AB).*(B( dot_AB,j)'));
%             AB(i,j)=mean(A(i,dot_B).*(B(dot_B,j)'));
%         else
%             AB(i,j)=0;
%         end
            AB(i,j)=max(A(i,:).*(B(:,j)'));
    end
end
end