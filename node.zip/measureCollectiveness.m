function [collectivenessSet, crowdCollectiveness, Z,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix] = measureCollectiveness( curX, curV, para)
%Objective: to measure the collectiveness of moving points.
%   curX:                   spatial location of points.
%   curV:                   velocity of points.
%   collectivenessSet:      individual collectiveness.
%   crowdCollectiveness:    crowd collectiveness

%% step 1: compute the weighted adjacency matrix using KNN
para.K=min(size(curX,1)-1,para.K);
[weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix] = computeAdj(curX, curV, para.K);
%% step 2: integrating all the paths with regularization
I_matrix = eye(size(weightedAdjacencyMatrix,1));
Z = inv(I_matrix-para.z*weightedAdjacencyMatrix) - I_matrix;
collectivenessSet = sum(Z,2);
crowdCollectiveness = mean(collectivenessSet);
end

function [weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix] = computeAdj(curX, curV, K)
distanceMatrix = slmetric_pw(curX',curX','eucdist');
correlationMatrix = slmetric_pw(curV',curV','nrmcorr');
[n,~]=size(curV);
K=min(K,n-1);
%% K-nearest neighbor adjacency matrix
neighborMatrix = zeros(size(distanceMatrix,1));
for i=1:size(distanceMatrix,1)
    [~,neighborIndex] = sort(distanceMatrix(i,:),'ascend');
    neighborMatrix(i,neighborIndex(2:K+1)) = 1;
end
weightedAdjacencyMatrix = (correlationMatrix.*neighborMatrix);%weigted adjacency matrix

Matrix_temp=[];Matrix_temp2=[];
% K+1��2K���ھ�
% neighborMatrix2 = zeros(size(distanceMatrix,1));
% for i=1:size(distanceMatrix,1)
%     [~,neighborIndex] = sort(distanceMatrix(i,:),'ascend');
%     neighborMatrix2(i,neighborIndex(K:min(n,K+20))) = 1;
% end
% 
% neighborMatrix3 = zeros(size(distanceMatrix,1));
% for i=1:size(distanceMatrix,1)
%     [~,neighborIndex] = sort(distanceMatrix(i,:),'ascend');
%     neighborMatrix3(i,neighborIndex(2:K+1)) = 1;
% end

% Matrix_temp1 =(correlationMatrix.*neighborMatrix);
% Matrix_temp2 =(correlationMatrix.*neighborMatrix2);
% Matrix_temp3  =(correlationMatrix.*neighborMatrix3);


% [Matrix_temp,Matrix_temp2]=getnewMatrix_temp(Matrix_temp1,Matrix_temp2,Matrix_temp3,neighborMatrix,curV,curX);%��Matrix_temp�и���Ԫ�ؿ���metric learning��cannot link


weightedAdjacencyMatrix=max(0,weightedAdjacencyMatrix);%���ӣ������ǷǸ���
weightedAdjacencyMatrix=min(weightedAdjacencyMatrix,1);%���ȴ���, Dec 03.
end

function [Matrix_temp,Matrix_temp2]=getnewMatrix_temp(Matrix_temp1,Matrix_temp2,Matrix_temp3,neighborMatrix,curV,curX)
X=curV';
[Xm,Xn]=size(X);
[x,y]=find(Matrix_temp2==1);
pairs_positive=[x,y];

[x,y]=find(Matrix_temp1<-0);
pairs_negative=[x,y];

[N1,~]=size(pairs_positive);
[N2,~]=size(pairs_negative);
X_Similar=[];X_Similar(:,1)=zeros(Xm,1);
N1_randperm=randperm(N1);
N2_randperm=randperm(N2);
% N1,N2
for i_N1=1:min(300,N1)
    select=N1_randperm(i_N1);
    X_Similar(:,i_N1)=X(:,pairs_positive(select,1))-X(:,pairs_positive(select,2));
end
X_Dissimilar=[];X_Dissimilar(:,1)=zeros(Xm,1);
for i_N2=1:min(500,N2)
    select2=N2_randperm(i_N2);
    X_Dissimilar(:,i_N2)=X(:,pairs_negative(select2,1))-X(:,pairs_negative(select2,2));
end
s1=X_Similar*X_Similar';
s2=X_Dissimilar*X_Dissimilar';
M1=inv(s1+eye(Xm)*10^(-4))-inv(s2+eye(Xm)*10^(-4));M = validateCovMatrix(M1);%to induce a valid pseudo metric we enforce that  M is p.s.d  by clipping the spectrum
M=M+eye(Xm)*10^(-4);%% add COIL20
P=chol(M);%M=P'*P;
% options=[];options.k=Xn;
% Matrix_temp = constructW(X'*P',options);
% Matrix_temp= (Matrix_temp.*neighborMatrix);
%%
Matrix_temp = slmetric_pw(P*X,P*X,'nrmcorr');
Matrix_temp= (Matrix_temp.*neighborMatrix);
Matrix_temp=max(0,Matrix_temp);
%% %%
X=curV';
[Xm,Xn]=size(X);
[x,y]=find(Matrix_temp3==1);
pairs_positive=[x,y];

[x,y]=find(Matrix_temp1<-0);
pairs_negative=[x,y];

[N1,~]=size(pairs_positive);
[N2,~]=size(pairs_negative);
X_Similar=[];X_Similar(:,1)=zeros(Xm,1);
N1_randperm=randperm(N1);
N2_randperm=randperm(N2);
% N1,N2
for i_N1=1:min(300,N1)
    select=N1_randperm(i_N1);
    X_Similar(:,i_N1)=X(:,pairs_positive(select,1))-X(:,pairs_positive(select,2));
end
X_Dissimilar=[];X_Dissimilar(:,1)=zeros(Xm,1);
for i_N2=1:min(500,N2)
    select2=N2_randperm(i_N2);
    X_Dissimilar(:,i_N2)=X(:,pairs_negative(select2,1))-X(:,pairs_negative(select2,2));
end
s1=X_Similar*X_Similar';
s2=X_Dissimilar*X_Dissimilar';
M1=inv(s1+eye(Xm)*10^(-4))-inv(s2+eye(Xm)*10^(-4));M = validateCovMatrix(M1);%to induce a valid pseudo metric we enforce that  M is p.s.d  by clipping the spectrum
M=M+eye(Xm)*10^(-4);%% add COIL20
P=chol(M);%M=P'*P;
%%
Matrix_temp2 = slmetric_pw(P*X,P*X,'nrmcorr');
Matrix_temp2= (Matrix_temp2.*neighborMatrix);
Matrix_temp2=max(0,Matrix_temp2);
end