function [collectivenessSet1, crowdCollectiveness1, collectivenessSet2, crowdCollectiveness2,Z1,Z2] = measureLannerness( curX, curV, para)
%Objective: to measure the collectiveness of moving points.
%   curX:                   spatial location of points.
%   curV:                   velocity of points.
%   collectivenessSet:      individual collectiveness.
%   crowdCollectiveness:    crowd collectiveness

%% step 1: compute the weighted adjacency matrix using KNN
% para.K =20;
% para.K=min(size(curX,1)-1,para.K);
% para.z = 0.5/para.K ;
% para.upperBound = para.K*para.z/(1-para.K*para.z);
% para.threshold = 0.4*para.z/(1-para.K*para.z);
[weightedAdjacencyMatrix,~] = computeAdj(curX, curV, para.K);
%% �Գƻ�Σ��
% weightedAdjacencyMatrix3=max(weightedAdjacencyMatrix,weightedAdjacencyMatrix');
%% step 2: integrating all the paths with regularization
% Z = inv(eye(size(weightedAdjacencyMatrix,1))-para.z*weightedAdjacencyMatrix) - I_matrix;
[~,n]=size(weightedAdjacencyMatrix);
%% ˥������
alfa_Z=descrease_factor(weightedAdjacencyMatrix,curX,curV);%���������౳����˥������
weightedAdjacencyMatrix_new=alfa_Z.*weightedAdjacencyMatrix;
%%
K1=max(sum( (weightedAdjacencyMatrix>0) ,2));
%% 1.n>400,k=20;n�仯ʱ���ʵ�para.K�ǹؼ� 2.˥��������Ч�� 3.
Z1= expm(weightedAdjacencyMatrix)/( exp(K1));
% Z1=Z1-diag(diag(Z1));
%%
% Z2 = inv(eye(size(weightedAdjacencyMatrix,1))-para.z*weightedAdjacencyMatrix_new) - eye(size(weightedAdjacencyMatrix,1));
%% �ָ�
Z2=Z1;
% K2=max(sum( (weightedAdjacencyMatrix_new>0) ,2));
% Z2= expm(weightedAdjacencyMatrix_new)/( exp(K2));
%%

% Z2=Z2-diag(diag(Z2));
% WG=weightedAdjacencyMatrix;
% D=diag(sum(WG,2));d=diag(D);d=max(eps,d);
% WG=eye(n)-diag(d.^(-1/2))*WG*diag(d.^(-1/2));
% Z2= expm(WG);
% Z2=Z2-diag(diag(Z2));

%%
% Z2=qianshu(weightedAdjacencyMatrix);
% Z2=qianshu_new_ok(weightedAdjacencyMatrix);
% Z2=qianshu_new_ok_sum(weightedAdjacencyMatrix);
% Z2=qianshu_new_ok_sum_2(weightedAdjacencyMatrix);


collectivenessSet1 = sum(Z1,2);
crowdCollectiveness1 = mean(collectivenessSet1);
% crowdCollectiveness1 = sum(collectivenessSet1)/ n;

collectivenessSet2 = sum(Z2,2);
crowdCollectiveness2 = sum(collectivenessSet2)/ n;
end

function [weightedAdjacencyMatrix,neighborMatrix] = computeAdj(curX, curV, K)
distanceMatrix = slmetric_pw(curX',curX','eucdist');
correlationMatrix = slmetric_pw(curV',curV','nrmcorr');
[n,~]=size(curV);
K=min(K,n-1);
%% K-nearest neighbor adjacency matrix
neighborMatrix = zeros(size(distanceMatrix,1));
for i=1:size(distanceMatrix,1)
    [~,neighborIndex] = sort(distanceMatrix(i,:),'ascend');
    neighborMatrix(i,neighborIndex(2:K+1)) = 1;
end
weightedAdjacencyMatrix = (correlationMatrix.*neighborMatrix);%weigted adjacency matrix
weightedAdjacencyMatrix=max(0,weightedAdjacencyMatrix);%���ӣ������ǷǸ���
weightedAdjacencyMatrix=min(weightedAdjacencyMatrix,1);%���ȴ���, Dec 03.
end
