function [FPR,TPR]=ROC_curve(a,b,threshold)
i=1;
for threshold=0:0.001:1
    FPR_hl(i)= sum( crowd_total(low)>threshold )  / low_do;
    TPR_hl(i)= sum( crowd_total(high)>threshold )  / high_do;
    
    FPR_ml(i)= sum( crowd_total(low)>threshold )  / low_do;
    TPR_ml(i)= sum( crowd_total(media)>threshold )  / media_do;
    
    FPR_hm(i)= sum( crowd_total(media)>threshold )  / media_do;
    TPR_hm(i)= sum( crowd_total(high)>threshold )  / high_do;
    
    i=i+1;
end