clc
clear
% addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
% addpath('dataset_evaluation\');addpath('gactoolbox\');addpath('old\');
% addpath('node clique learningʵ����\')
load humanGT.mat
load('collectivenessVideoResult.mat')
load('matlab0.mat')
Human_table=sum(GT_human);%Scores
Human_table_mod=mode(GT_human);%����,votting

collectivenessClips=cell2mat(collectivenessData(2,:));
% velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;

Z_wenxian=collectivenessClips;%ԭʼ���׽������Z-inv��ͬ������������W�ļ��㲻ͬ.
%%
% Z_wenxian
% Z_exp_K20;Z_inv_K20;NCL1_min_nata09_K20;NCL2_min_nata09_K20;curOrder_total
% NCL1_avg_nata08_K20;NCL2_avg_nata08_K20;
% crowd_total=curOrder_total;
crowd_total=Z_wenxian;
% crowd_total=Z_inv_K20;
% crowd_total=Z_exp_K20;

% crowd_total=NCL1_avg_nata07_K20;
% crowd_total=NCL2_avg_nata07_K20;
% crowd_total=NCL1_min_nata07_K20;
% crowd_total=NCL2_min_nata07_K20;

% crowd_total=NCL1_avg_nata08_K20;
% crowd_total=NCL2_avg_nata08_K20;
% crowd_total=NCL1_min_nata08_K20;
% crowd_total=NCL2_min_nata08_K20;

% crowd_total=NCL1_avg_nata09_K20;
% crowd_total=NCL2_avg_nata09_K20;
% crowd_total=NCL1_min_nata09_K20;
% crowd_total=NCL2_min_nata09_K20;
%% scores
% 1.���ϵ��
co1=corrcoef(crowd_total,Human_table); 
coffcient_scores=co1(1,2);

co2=corrcoef(crowd_total,Human_table_mod); 
coffcient_votting=co2(1,2);
coffcient=[coffcient_scores,coffcient_votting];
disp('1.cofficient')
disp('    Scores   Votting')
disp(coffcient)
%  2.ROC 3.ƽ������׼ȷ��
% disp(' ')
disp('------------------scores-------------------')
% disp(' ')
[acu_high_low1,acu_high_media1,acu_media_low1]=acuracy_for_all_roc(crowd_total,Human_table,Human_table_mod,1);%acuracy_for_all,acuracy_for_all2:norm SME  svm.
disp('4.ƽ������׼ȷ��')
% disp('  High_low  High_media Media_low')
acu1=[acu_high_low1,acu_high_media1,acu_media_low1];
disp(acu1)
%%    voting
% 1.���ϵ�� % 2.ƽ������׼ȷ�� 3.ROC
% disp(' ')
disp('-------------------votting-------------------')
% disp(' ')
[acu_high_low2,acu_high_media2,acu_media_low2]=acuracy_for_all_roc(crowd_total,Human_table,Human_table_mod,2);%acuracy_for_all,acuracy_for_all2:norm SME  svm.
acu2=[acu_high_low2,acu_high_media2,acu_media_low2];
disp('4.ƽ������׼ȷ��')
disp(acu2)
%        