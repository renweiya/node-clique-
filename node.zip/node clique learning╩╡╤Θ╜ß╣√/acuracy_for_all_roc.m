function [acu_high_low,acu_high_media,acu_media_low]=acuracy_for_all_roc(crowd_total,Human_table,Human_table_mod,select)
%  select=1
if select==1
    Human_table=Human_table(1:length(crowd_total));
    high=(Human_table>15)+(Human_table==15);
    media=(Human_table<15).*(Human_table>5);
    low=(Human_table<5)+(Human_table==5);
    high=logical(high);media=logical(media);low=logical(low);
end
if select==2
    Human_table_mod=Human_table_mod(1:length(crowd_total));
    high=(Human_table_mod==2);
    media=(Human_table_mod==1);
    low=(Human_table_mod==0);
end


acu_high_low=[];acu_media_low=[];acu_high_media=[];

%
high_do=max(eps,sum(high));
low_do=max(eps,sum(low));
media_do=max(eps,sum(media));
i=1;
%%ȫ��һ����Ԫ����ʧЧ
for threshold=0:0.001:1
    acu_high_low(i)  = (sum(crowd_total(high)>threshold)/high_do+sum(crowd_total(low)<threshold)/low_do )/2;
    acu_high_media(i)= (sum(crowd_total(high)>threshold)/high_do+sum(crowd_total(media)<threshold)/media_do )/2;
    acu_media_low(i) = (sum(crowd_total(media)>threshold)/media_do+sum(crowd_total(low)<threshold)/low_do )/2;
    i=i+1;
end
acu_high_low=max(acu_high_low);
acu_high_media=max(acu_high_media);
acu_media_low=max(acu_media_low);

%% precision TP/(TP+FP) recall=TP/P
% true class:True(����P),False(����N)
%     ��������Postive,Negative
% TP��True Positives,  FP��false positive
% FN��False Negatives, TN:True Negatives
% i=1;
% for threshold=0:0.001:1
%      pre_high_low(i)=sum(crowd_total(high)>threshold) / max(eps,(sum(crowd_total(high)>threshold)+sum(crowd_total(low)>threshold)));
%      pre_media_low(i)=sum(crowd_total(media)>threshold) /max(eps, (sum(crowd_total(media)>threshold)+sum(crowd_total(low)>threshold)));
%      pre_high_media(i)=sum(crowd_total(high)>threshold) / max(eps,(sum(crowd_total(high)>threshold)+sum(crowd_total(media)>threshold)));
%      recall...
%      recall...
%      recall...
%      i=i+1;
% end
 
% x=[crowd_total(high),crowd_total(media)];
% x=x';
% training_label_vector=[ones(1,sum(high)),-1*ones(1,sum(media))];
% training_label_vector=training_label_vector';
% model = svm_learning(x, training_label_vector,0,0.1)
% [~, accuracy, ~] = svm_classifying(model, x, training_label_vector, 0)
%% �����������ROC���ߣ�AUC
%ROC�����µ������AUC,FRP=FP/N.TRP=TP/P;
FRP_high_low=[];TRP_high_low=[];
FRP_media_low=[];TRP_media_low=[];
FRP_high_media=[];TRP_high_media=[];
i=1;
for threshold=0:0.001:1
    FRP_high_low(i)= sum( crowd_total(low)>threshold )  / low_do;
    TRP_high_low(i)= sum( crowd_total(high)>threshold )  / high_do;
    
    FRP_high_media(i)= sum( crowd_total(media)>threshold )  / media_do;
    TRP_high_media(i)= sum( crowd_total(high)>threshold )  / high_do;
    
    FRP_media_low(i)= sum( crowd_total(low)>threshold )  / low_do;
    TRP_media_low(i)= sum( crowd_total(media)>threshold )  / media_do;
   
    i=i+1;
end
%% 2 ROC���ߣ�AUC-���ȵ�
% target=[ones(1,high_do),zeros(1,low_do)];outputs=[crowd_total(high),crowd_total(low)];
% [tpr_hl,fpr_hl,thresholds_hl] = roc(target,outputs);
% AUC_hl=trapz(fpr_hl, tpr_hl)
% 
% 
% target=[ones(1,high_do),zeros(1,media_do)];outputs=[crowd_total(high),crowd_total(media)];
% [tpr_hm,fpr_hm,thresholds_hm] = roc(target,outputs);
% AUC_hm=trapz(fpr_hm, tpr_hm)
% 
% target=[ones(1,media_do),zeros(1,low_do)];outputs=[crowd_total(media),crowd_total(low)];
% [tpr_ml,fpr_ml,thresholds] = roc(target,outputs);
% AUC_ml=trapz(fpr_ml,tpr_ml)
%%

% [AUC_high_low,auc_high_low]=get_AUC_from_ROC(FRP_high_low, TRP_high_low);
% [AUC_high_media,auc_high_media]=get_AUC_from_ROC(FRP_high_media, TRP_high_media);
% [AUC_media_low,auc_media_low]=get_AUC_from_ROC(FRP_media_low, TRP_media_low);

AUC_high_low=-trapz(FRP_high_low, TRP_high_low);
AUC_high_media=-trapz(FRP_high_media, TRP_high_media);
AUC_media_low=-trapz(FRP_media_low, TRP_media_low);


% x=0:0.001:1;y1=TRP_high_low;y2=TRP_media_low;y3=TRP_high_media;
% auc00003=[trapz(x,y1),trapz(x,y2),trapz(x,y3)]
disp('2.ROC')
AUC_hl_hm_ml=[AUC_high_low,AUC_high_media,AUC_media_low];
% auc_hl_hm_ml=[auc_high_low,auc_high_media,auc_media_low];
disp('  High_low  High_media Media_low')
% disp(' ')
% M=[AUC_hl_hm_ml;auc_hl_hm_ml];
% disp(M)
disp(AUC_hl_hm_ml) %������
% disp(auc_hl_hm_ml)
% plot( FRP_high_media,TRP_high_media,'DisplayName','TRP vs. FRP','XDataSource','FRP','YDataSource','TRP');figure(gcf);
%% �������׼ȷ��
i=1;
binary_high_low=[];
binary_media_low=[];
binary_high_media=[];
boundary=[];
for threshold=0:0.001:1
   binary_high_low(i)  =( sum( crowd_total(high)>threshold)+ sum( crowd_total(low)<threshold) ) /(high_do+low_do);
   binary_media_low(i) =( sum( crowd_total(media)>threshold)+ sum( crowd_total(low)<threshold) ) /(media_do+low_do);
   binary_high_media(i)=( sum( crowd_total(high)>threshold)+ sum( crowd_total(media)<threshold) ) /(high_do+media_do);
   boundary(i)=threshold;
   i=i+1;
end
[m1,n1]=max(binary_high_low);
[m2,n2]=max(binary_high_media);
[m3,n3]=max(binary_media_low);

disp('3.���������ȷ��')
% disp('  High_low  High_media Media_low')
disp([[m1,boundary(n1)]',[m2,boundary(n2)]',[m3,boundary(n3)]'])
% disp([m1,m2,m3])