%% Measuring collectiveness at each frame of a video
clear; clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
clip_dir = 'video_clips';
% sub_dirs = dir(clip_dir);
% sub_dirs = sub_dirs(3:end);
% b_dir = [sub_dirs.isdir];
% sub_dirs = {sub_dirs(b_dir).name};
%%
collectivenessClips=cell2mat(collectivenessData(2,:));
velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
Human_table=sum(GT_human);
%%
% folder_name = uigetdir(clip_dir);
% [root, folder] = fileparts(folder_name);
% idx_temp = strcmp(sub_dirs, folder);%��һ���ļ�list���ҵ�һ���ļ���
% idx=find(idx_temp);
%%
select_idx=randperm(413);
idx=select_idx(1)
% idx=212
folder=sub_dirs{idx};
%%
curVideo = fullfile('video_clips', folder);

% curVideo = 'realcrowd\';
curTrkName = 'klt_3000_10_trk.txt';
% curTrkName = 'klt_3000_10_trk_filt.txt';
%%
do_cluster=1;
%% Collectiveness parameter
para.K = 20;%20���ھ�-KNN
para.z = 0.5/para.K ;
para.upperBound = para.K*para.z/(1-para.K*para.z);
para.threshold = 0.6*para.z/(1-para.K*para.z);
%%
curClipFrameSet = dir([curVideo '\*.jpg']);
curTrks = readTraks([curVideo '\' curTrkName]);
[XVset] = trk2XV(curTrks, 1, 2); %��Ҫһ�д���-�켣���� % transform trajectories into point set
%% ȥ���ٶ�Ϊ0�ĵ�--����
zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
% zeroindex=find(sum(abs(XVset(:,3:4)),2)<3);
XVset(zeroindex,:)=[];
%%
if do_cluster==1
    figure
    set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.8]);
end
Map=[];
curFrame = imread([curVideo '\' curClipFrameSet(1).name]);
%%
msparse2_onevideo=[];
msparse3_onevideo=[];
for i = 1:length(curClipFrameSet)
    i
    curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
    curFrame = im2double(curFrame);
    [Lm,Ln,Lk]=size(curFrame);
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    %%
    curOrder = SDP_order(curV); % average velocity measurement
    tic
    [collectivenessSet, crowdCollectiveness, Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
    toc
    %% collective map
    Map(:,:,i)=getcollectiveMap(curX,collectivenessSet,Lm,Ln);
    %% threshold clustering
    clusterIndex = collectiveMerging( Zmatrix, para ); % get clusters from Z matrix
    if do_cluster==1 && length(curIndex)>5
        %% from Z to WG
       [WG2,WG3,WG4,WG5,rightpoint2,rightpoint3,rightpoint4,rightpoint5]=getgraph3(Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix,clusterIndex,para);
        %% nClas-��Ҫ
        %         nClass=min(20,max(2,max(clusterIndex)));
        %         nClass=4;
        %         nClass=max(2,max(clusterIndex));
        % ȷ�������
        nClass2=give_number_of_clusters_forSC(WG2)
        nClass3=give_number_of_clusters_forSC(WG3)%ʧЧ
%         nClass=max(2,min(nClass2,max(clusterIndex)));
        
%         distance_matrix = distmat(curX);
        [~, distance_matrix, clusterNum] = fun_gac_init(curX, 1, para.K);%Graph Degree Linkage-agglomerative clustering-modularity function-too slow
        clusterNum
        nClass=max(2,min(nClass2,clusterNum));
%         nClass2
%         nClass3
        %%
        if ~isempty(rightpoint2)
            %% ȡʹ�ý�ƽ��ϡ�����ߵ�nClass
            %             for j=1:7
            %                 j
            %                 nClass=j+1;
            %                 V=softspectralclustering(WG,nClass,0.01,1);
            %                 sparseness00(j)=sparseness(V);
            %             end
            %             [m1,n1]=max(sparseness00);
            %             nClass=n1+1;
            %% CAC
            clusterIndex2=zeros(1,size(curX,1));
            %             V2=ncutW(WG,nClass);
            %             V2=Eigenmap(WG,nClass);
            V2=softspectralclustering(WG3,nClass,0.01,1);
            %             V2=ratiocut(WG2,nClass,0.01);
            %             V2=minmaxCAC(WG2,nClass,0.01,1);
            label2 = litekmeans(V2,nClass,'Replicates',20);
            clusterIndex2(rightpoint3)=label2;
            %% CAC
            clusterIndex3=zeros(1,size(curX,1));
            V3=softspectralclustering(WG4,nClass,0.01,1);
            %%
            %             X=curX';
            %             X=X(:,rightpoint2);
            %             if i==1
            %                 [U,V3]=CAC_RNMF(X,WG,nClass,100,100,1);
            %                 detaU=U;
            %             else
            %                 [U,V3]=CAC_RNMF_smooth(X,WG,nClass,detaU,100,100,100,1);
            %                 detaU=U;
            %             end
            %
            label3 = litekmeans(V3,nClass,'Replicates',20);
            clusterIndex3(rightpoint4)=label3;
            %% SC
            clusterIndex4=zeros(1,size(curX,1));
%             V4=ncutW(WG3,nClass);
%             V4=Eigenmap(WG3,nClass);
            % V4=normalizedlaplacian(WG,nClass);
            V4=softspectralclustering(WG5,nClass,0.01,1);
            label4 = litekmeans(V4,nClass,'Replicates',20);
            clusterIndex4(rightpoint5)=label4;
            %% ������𷽲� �� ϡ��� ����ۼ���
            variate_forsparse2=get_variate_from_tabulate(clusterIndex2);
            variate_forsparse3=get_variate_from_tabulate(clusterIndex3);
            variate_forsparse4=get_variate_from_tabulate(clusterIndex4);
            %% ϡ��� ����
            [msparse2,sparse2]=sparseness(V2);
            [msparse3,sparse3]=sparseness(V3);
            [msparse4,sparse4]=sparseness(V4);
            msparse2_onevideo(i)= (variate_forsparse2*msparse2);
            msparse3_onevideo(i)= (variate_forsparse3*msparse3);
            msparse4_onevideo(i)= (variate_forsparse4*msparse4);
            crowdCollectiveness_onevideo(i)=crowdCollectiveness;
        else
            clusterIndex2=zeros(1,size(curX,1));
            clusterIndex3=zeros(1,size(curX,1));
            clusterIndex4=zeros(1,size(curX,1));
            variate_forsparse2=0;variate_forsparse3=0;variate_forsparse4=0;msparse2=0;msparse3=0;msparse4=0;
        end
        %% draw
        drawcluster;
    end
end
score_all=Human_table(idx);
collectivenessClips(idx)
mean(crowdCollectiveness_onevideo)