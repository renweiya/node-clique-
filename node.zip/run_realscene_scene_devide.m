%% Measuring collectiveness at each frame of a video
clear; clc
addpath('util\');addpath('Algorithms\');addpath('Ncut\');addpath('Ncut_9\');
addpath('dataset_evaluation\');addpath('gactoolbox\');
load humanGT.mat
load('collectivenessVideoResult.mat');
%%
clip_dir = 'video_clips';
% sub_dirs = dir(clip_dir);
% sub_dirs = sub_dirs(3:end);
% b_dir = [sub_dirs.isdir];
% sub_dirs = {sub_dirs(b_dir).name};
%%
collectivenessClips=cell2mat(collectivenessData(2,:));
velocityOrderClips=cell2mat(velocityOrderData(2,:));
sub_dirs=GT_videoIndex;
Human_table=sum(GT_human);
%%
% folder_name = uigetdir(clip_dir);
% [root, folder] = fileparts(folder_name);
% idx_temp = strcmp(sub_dirs, folder);%��һ���ļ�list���ҵ�һ���ļ���
% idx=find(idx_temp);
%%
select_idx=randperm(413);
idx=select_idx(1)
idx=77
%% Z1(expm) K=20,threshold=0.0001
% final use: idx= 20,70,121,143,235,251,256,261,303.
% ����idx=77,96,212,243,273.
% ����idx=5-,   20,  53, 70,   77, 80-, 96,121,143,212
% ����idx=235, 243, 251, 256, 261,273, 303,315,323,346-
% ����idx=167-,197-

% clustering good idx=49,52,70,235,250,251,255,273,315
% idx=5,20,53,77,80,81,96,121,143,146,153,167,184,187,197,212
% idx=215,225,243,255,256,261,273,303,323,342,346,348,364,404
folder=sub_dirs{idx}
%%
curVideo = fullfile('video_clips', folder);

% curVideo = 'realcrowd\';
curTrkName = 'klt_3000_10_trk.txt';
% curTrkName = 'klt_3000_10_trk_filt.txt';
%%
do_cluster=1;
%%
curClipFrameSet = dir([curVideo '\*.jpg']);
curTrks = readTraks([curVideo '\' curTrkName]);
[XVset] = trk2XV(curTrks, 1, 2); %��Ҫһ�д���-�켣���� % transform trajectories into point set
%% ȥ���ٶ�Ϊ0�ĵ�--����
% % zeroindex=find(sum(abs(XVset(:,3:4)),2)==0);
% % XVset(zeroindex,:)=[];
%%
if do_cluster==1
    figure
    set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.8]);
end
Map=[];Map1=[];
curFrame = imread([curVideo '\' curClipFrameSet(1).name]);
%%
% for i = 2:length(curClipFrameSet)
for i = 10:10
    i
    curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
    curFrame = im2double(curFrame);
    [Lm,Ln,Lk]=size(curFrame);
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    %%
    %     curOrder = SDP_order(curV); % average velocity measurement
    para.K=20;para.z = 0.5/para.K ;para.upperBound = para.K*para.z/(1-para.K*para.z);para.threshold = 0.6*para.z/(1-para.K*para.z);
    [collectivenessSet, crowdCollectiveness, Zmatrix,weightedAdjacencyMatrix,Matrix_temp,Matrix_temp2,neighborMatrix]  = measureCollectiveness( curX, curV, para);%crowd collectiveness
    
    para.K=20;
    [collectivenessSet1, crowdCollectiveness1, collectivenessSet2, crowdCollectiveness2,Z1,Z2] = measureLannerness( curX, curV, para);
    %     toc
    %% collective map
    %     Map(:,:,i)=getcollectiveMap(curX,collectivenessSet,Lm,Ln);
    %     Map1(:,:,i)=getcollectiveMap(curX,collectivenessSet1,Lm,Ln);
    %% threshold clustering
    clusterIndex = collectiveMerging( Zmatrix,  para ); % get clusters from Z matrix
    %%
%     para.threshold=0;
% clusterIndex = collectiveMerging_SDP( Z, para,dismiss);%too slow-�Ķ�������
%     clusterIndex = collectiveMerging_clique(Z1, special,1);%�Ա࣬much faster than above
    %%
    special.threshold=10^(-5);
%     H=special.K;
%     special.threshold=0.01*(1/H+1/exp(H)-1/(H*exp(H)));
    clusterIndex11 = collectiveMerging( Z1,  special); % get clusters from Z matrix
    if do_cluster==1 && length(curIndex)>5
        %% from Z to WG
        %         [WG2,WG3,rightpoint2,rightpoint3]=getgraph3(Zmatrix,weightedAdjacencyMatrix,curX, curV,clusterIndex,para);
        
        %         [WG2,rightpoint2,nClass2]=getgraph_alone(curX,curV,clusterIndex,para.K);
        %         WG2=max(WG2,WG2');
        
        %         [WG3,rightpoint3,nClass3]=getgraph_alone(curX,curV,clusterIndex,20);
        %         [WG2,rightpoint2,nClass2]=getgraph_byZ(Zmatrix,clusterIndex,para.threshold);
        %%
%         weightedAdjacencyMatrix00 = computeAdj(curX, curV, 5);
        [WG2,rightpoint2,nClass2]=getgraph_byZ(Z1,clusterIndex11,special.threshold);
%         [WG2,rightpoint2,nClass2]=getgraph_weight(weightedAdjacencyMatrix00,clusterIndex11);
        
        [WG3,rightpoint3,nClass3]=getgraph_weight(weightedAdjacencyMatrix,clusterIndex11);
        
        [WG4,rightpoint4,nClass4]=getgraph_weight(weightedAdjacencyMatrix,clusterIndex11);
        %         [WG4,rightpoint4,nClass4]=getgraph_weight2(weightedAdjacencyMatrix,clusterIndex11);
        
        %         [WG4,rightpoint4,nClass4]=getgraph_byZ(Z1,clusterIndex11,special.threshold);
        
        %          [WG4,rightpoint4,nClass4]=getgraph_alone(curX,curV,clusterIndex11,special.K);
        
        %          special.threshold=0.0001;
        %         [WG21,rightpoint21]=getgraph31(Z1,clusterIndex11,special.threshold);
        %% nClas-��Ҫ
        %    nClass200=give_number_of_clusters_forSC(WG2)
        %         nClass2=max(2,min(nClass200,max(clusterIndex)))
        %         toc
        %         nClass21=give_number_of_clusters_forSC(WG21)
        %         nClass3=give_number_of_clusters_forSC(WG3)%ʧЧ
        % %         distance_matrix = distmat(curX);
        %         [~, distance_matrix, clusterNum] = fun_gac_init(curX, 1, para.K);%Graph Degree Linkage-agglomerative clustering-modularity function-too slow
        %         nClass=max(2,min(nClass2,clusterNum));
        %%
        if  isempty(WG2)||isempty(WG3)||isempty(WG4)
            clusterIndex2=zeros(1,size(curX,1));
            clusterIndex3=zeros(1,size(curX,1));
            clusterIndex4=zeros(1,size(curX,1));
        else
            %             drawcluster;
            %         end
            %         if ~isempty(rightpoint21)
            %% ȡʹ�ý�ƽ��ϡ�����ߵ�nClass
            %             for j=1:7
            %                 j
            %                 nClass=j+1;
            %                 V=softspectralclustering(WG,nClass,0.01,1);
            %                 sparseness00(j)=sparseness(V);
            %             end
            %             [m1,n1]=max(sparseness00);
            %             nClass=n1+1;
            %% CAC
            clusterIndex2=zeros(1,size(curX,1));
            %             V2=ncutW(WG2,nClass2);
            %             V2=Eigenmap(WG2,nClass2);
            V2=softspectralclustering(WG2,nClass2,0.01,1);
            %             V2=ratiocut(WG2,nClass,0.01);
            %             V2=minmaxCAC(WG2,nClass,0.01,1);
            label2 = litekmeans(V2,nClass2,'Replicates',20);
            clusterIndex2(rightpoint2)=label2;
            %% CAC
            clusterIndex3=zeros(1,size(curX,1));
            V3=softspectralclustering(WG3,nClass3,0.01,1);
            label3 = litekmeans(V3,nClass3,'Replicates',20);
            clusterIndex3(rightpoint3)=label3;
            %%
            %             X=curX';
            %             X=X(:,rightpoint2);
            %             if i==1
            %                 [U,V3]=CAC_RNMF(X,WG,nClass,100,100,1);
            %                 detaU=U;
            %             else
            %                 [U,V3]=CAC_RNMF_smooth(X,WG,nClass,detaU,100,100,100,1);
            %                 detaU=U;
            %             end
            %
            
            %% SC
            clusterIndex4=zeros(1,size(curX,1));
            %             V4=ncutW(WG3,nClass);
            V4=Eigenmap(WG4,nClass4);
            % V4=normalizedlaplacian(WG,nClass);
            %             V4=softspectralclustering(WG4,nClass4,0.01,1);
            label4 = litekmeans(V4,nClass4,'Replicates',20);
            clusterIndex4(rightpoint4)=label4;
            %% ������𷽲� �� ϡ��� ����ۼ���
            %             variate_forsparse2=get_variate_from_tabulate(clusterIndex2);
            %% ϡ��� ����
            %             [msparse2,sparse2]=sparseness(V2);
            crowdCollectiveness_onevideo(i)=crowdCollectiveness;
        end
        %% draw
        tic
        drawcluster;
        toc
    end
end
score_all=Human_table(idx);
collectivenessClips(idx)
mean(crowdCollectiveness_onevideo)