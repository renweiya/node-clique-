%% Measuring collectiveness at each frame of a video
%% ���ø��ٽ������
%% �Ͻ� run_realscene
do_cluster=1;Map2=[];
for i = 1:length(curClipFrameSet)
    i
    curFrame = imread([curVideo '\' curClipFrameSet(i).name]);
    curFrame = im2double(curFrame);
    curIndex = find(XVset(:, 5) == i);
    curX = XVset(curIndex,1:2);  %����
    curV = XVset(curIndex,3:4);  %�ٶ�
    curOrder = SDP_order(curV); % average velocity measurement
    [collectivenessSet, crowdCollectiveness, Zmatrix] = measureCollectiveness( curX, curV, para);%crowd collectiveness
    %% step 1: compute the weighted adjacency matrix using KNN
    weightedAdjacencyMatrix = computeAdj(curX, curV, para.K);
    %% threshold clustering
    clusterIndex = collectiveMerging( Zmatrix, para ); % get clusters from Z matrix
    if do_cluster==1
        %% Graph
        WG = weightedAdjacencyMatrix > para.threshold;%0-1ͼ�����Գ�
        %         WG2 =  Zmatrix > para.threshold;%0-1ͼ�����Գ�
        %         WG1=max(WG1,WG1'); WG2=max(WG2,WG2');
        %         WG=min(WG1,WG2);
        % or
        %         WG=weightedAdjacencyMatrix;WG(weightedAdjacencyMatrix<para.threshold)=0;%weight ͼ
        % �Գƻ�
        WG=max(WG,WG');
        noisepoint=find(sum(WG,2)==0);%������
        rightpoint=find(sum(WG,2)~=0);
        % ȥ��������
        WG(noisepoint,:)=[];
        WG(:,noisepoint)=[];
        WG=real(WG);
        %%
        %         nClass=3;
        %         if i>60
        %             nClass=2;
        %         end
        nClass=min(5,max(2,max(clusterIndex)));
        %     nClass=2;
        if length(noisepoint)<size(curX,1)
            %% Ncut
            clusterIndex2=zeros(1,size(curX,1));
            V2=ncutW(WG,nClass);
            %             V2=ones(size(WG,1),nClass);
            label2 = litekmeans(V2,nClass,'Replicates',20);
            clusterIndex2(rightpoint)=label2;
            %% CAC
            clusterIndex3=zeros(1,size(curX,1));
            V3=softspectralclustering(WG,nClass,0.01,1);
            label3 = litekmeans(V3,nClass,'Replicates',20);
            clusterIndex3(rightpoint)=label3;
            %% Normal_Ncut or CAC
            clusterIndex4=zeros(1,size(curX,1));
            %             V4=softspectralclustering(WG,nClass,1,1,0);
            V4=Eigenmap(WG,nClass);
            %                     V4=normalizedlaplacian(WG,nClass);
            %             V4=ones(size(WG,1),nClass);
            label4 = litekmeans(V4,nClass,'Replicates',20);
            clusterIndex4(rightpoint)=label4;
            %%
            N=length(noisepoint)+length(rightpoint);
            collectivenessSet1=zeros(N,1);
            [msparse,sparse]=sparseness(V3);
            collectivenessSet1(rightpoint)=sparse;
            %% collective map
            Map2(:,:,i)=getcollectiveMap(curX,collectivenessSet1,Lm,Ln);
        else
            clusterIndex2=zeros(1,size(curX,1));
            clusterIndex3=zeros(1,size(curX,1));
            clusterIndex4=zeros(1,size(curX,1));
            Map2(:,:,i)=zeros(Lm,Ln);
        end
        %% draw
        drawcluster;
    end
end
