/*
 * sumax.cpp
 *
 *  Created on: 2016��11��24��
 *      Author: Administrator
 */

/*
 * #include <stdio.h>
 * #include <stdlib.h>
 *
 * float ** summax_matrix(int NMatrix, float **AMatrix, float **BMatrix)
 * {
 * int i, j, k;
 *
 * float **CMatrix = malloc(NMatrix*sizeof(float *));
 * for(i = 0; i < NMatrix; i++)
 * {
 * CMatrix[i] = malloc(NMatrix*sizeof(float));
 * for(j = 0; j < NMatrix; j++)
 * {
 * CMatrix[i][j] = 0.0;
 * }
 * }
 *
 * for(i = 0; i< NMatrix; i++)
 * {
 * for(j = 0; j < i+1 ; j++)
 * {
 * for(k = 0; k < NMatrix; k++)
 * {
 * CMatrix[i][j] += ( AMatrix[i][k] >= BMatrix[k][j] ? AMatrix[i][k] : BMatrix[k][j] );
 * }
 * }
 * }
 *
 * return CMatrix;
 * }
 */
#include <mex.h>

int NMatrix, MMatrix;
double *AMatrix, *BMatrix;
int i, j, k;
double *CMatrix;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    AMatrix = mxGetPr(prhs[0]);
    BMatrix = mxGetPr(prhs[1]);
    
    MMatrix = mxGetM(prhs[0]);//���������
    NMatrix = mxGetN(prhs[0]);//���������
    
    if(nrhs != 2)
    {
        mexErrMsgTxt("There should be 2 inputs to call this function!\n");
    }
    
    if(MMatrix != NMatrix)
    {
        mexErrMsgTxt("Input matrixes are not square matrix!\n");
    }
    
    MMatrix = mxGetM(prhs[1]);
    if(MMatrix != NMatrix)
    {
        mexErrMsgTxt("Dimension of the 2 input matrixes are not equal!\n");
    }
    
    
    plhs[0] = mxCreateDoubleMatrix(MMatrix, NMatrix, mxREAL);
    CMatrix = mxGetPr(plhs[0]);
    
    
   
//       for(i = 0; i < NMatrix; i++)
//       {
//       for(j = 0; j < NMatrix; j++)
//       {
//       CMatrix[i+j*NMatrix] = 0.0;
//       }
//       }
   
    for(i = 0; i< (NMatrix-1); i++)
    {
        for(j = i+1; j < NMatrix ; j++)
        {
            for(k = 0; k < NMatrix; k++)
            {
//                 if(AMatrix[i+k*NMatrix] >= BMatrix[k+j*NMatrix])
                if(AMatrix[i+k*NMatrix]- BMatrix[k+j*NMatrix]>=1.0e-8)//Ӧ��0��0�����
                {
                    CMatrix[i+j*NMatrix] += AMatrix[i+k*NMatrix];//CMatrix[i+j*NMatrix] += (AMatrix[i+k*NMatrix] || BMatrix[k+j*NMatrix]);
                }
                else
                {
                    CMatrix[i+j*NMatrix] += BMatrix[k+j*NMatrix];
                }
            }
        }
    }
}
